# -*- coding: utf-8 -*-
# 仓鼠拼豆图纸 v2：Lab 量化 + 高饱和色(红框眼镜/樱桃/绿叶)保护 + 对称 + 同色号合并 + 白边
import math
from PIL import Image, ImageDraw, ImageFont
from collections import Counter

import argparse, os

SRC_DEFAULT = r"D:\Downloads\share_a9f25a347222da9d18082fbe0914281b.webp"
OUT_DEFAULT = r"D:\wb-data\2026-10-17-16-21-02\仓鼠拼豆图纸.png"
PAD = 3  # 图纸四周白色留边(格)

# ---------- 解析输入图片：命令行参数 > 文件选择对话框 > 默认仓鼠图 ----------
def pick_input_path():
    ap = argparse.ArgumentParser(description="把图片转成拼豆(像素)图纸")
    ap.add_argument("-i", "--input", help="输入图片路径（不提供则弹出文件选择框）")
    ap.add_argument("-o", "--output", help="输出 PNG 路径（默认：输入图同目录下的 <原名>_拼豆图纸.png）")
    args = ap.parse_args()
    if args.input:
        return args.input, args.output
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk(); root.withdraw()
        path = filedialog.askopenfilename(
            title="选择要转成拼豆图纸的图片",
            filetypes=[("图片", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("所有文件", "*.*")])
        root.destroy()
        if path:
            return path, args.output
    except Exception as e:
        print("无法弹出文件选择框：", e)
    print("未选择图片，使用默认仓鼠图：", SRC_DEFAULT)
    return SRC_DEFAULT, args.output

_raw_src, _raw_out = pick_input_path()
if not os.path.exists(_raw_src):
    raise SystemExit(f"找不到输入图片：{_raw_src}")

if _raw_out:
    OUT = _raw_out
else:
    _stem, _ext = os.path.splitext(_raw_src)
    OUT = f"{_stem}_拼豆图纸.png"
SRC = _raw_src

PALETTE = [
 ('A1','白色','#FFFFFF'),('A2','乳白','#FDF6E3'),('A3','米黄','#F5E6C8'),('A4','浅黄','#FFE08A'),
 ('A5','黄','#FFD335'),('A6','橙黄','#FFA826'),('A7','橙','#FF7F27'),('A8','大红','#E8362D'),
 ('A9','深红','#B01818'),('B1','酒红','#8E1F2F'),('B2','粉','#FF9EB5'),('B3','桃粉','#FFC1C1'),
 ('B4','肤色','#F8D0B0'),('B5','浅棕','#D9A05B'),('B6','棕','#9C6B30'),('B7','深棕','#6B4423'),
 ('B8','浅灰','#D9D9D9'),('B9','灰','#9E9E9E'),('C1','深灰','#5B5B5B'),('C2','黑','#1E1E1E'),
 ('C3','浅绿','#A8D878'),('C4','绿','#4CAF50'),('C5','深绿','#2E6B34'),('C6','天蓝','#7EC8E3'),
 ('C7','蓝','#3B82C4'),('C8','深蓝','#27496D'),('C9','紫','#9B59B6'),('D1','浅紫','#C9A7E0')]
def hex2rgb(h): return tuple(int(h[i:i+2],16) for i in (1,3,5))
PAL_RGB=[hex2rgb(c[2]) for c in PALETTE]

def rgb2lab(r,g,b):
    r/=255;g/=255;b/=255
    def f(c): return c/12.92 if c<=0.04045 else ((c+0.055)/1.055)**2.4
    R,G,B=f(r),f(g),f(b)
    X=R*0.4124+G*0.3576+B*0.1805; Y=R*0.2126+G*0.7152+B*0.0722; Z=R*0.0193+G*0.1192+B*0.9505
    X/=0.95047; Z/=1.08883
    fx=math.cbrt(X) if X>0.008856 else 7.787*X+16/116
    fy=math.cbrt(Y) if Y>0.008856 else 7.787*Y+16/116
    fz=math.cbrt(Z) if Z>0.008856 else 7.787*Z+16/116
    return (116*fy-16,500*(fx-fy),200*(fy-fz))
PAL_LAB=[rgb2lab(*c) for c in PAL_RGB]

def is_accent(lab):
    """红/绿等高饱和色：a* 明显占优(红系) 或 a* 强负(绿系)。棕/黄 b* 占优不算。"""
    L,a,b=lab
    chroma=math.hypot(a,b)
    if a>b+5 and chroma>18: return True   # 红系(含深红/酒红/桃粉)
    if a<-6 and chroma>20: return True    # 绿系
    return False

def dist(a,b): return (a[0]-b[0])**2+(a[1]-b[1])**2+(a[2]-b[2])**2

RED_IDS=[i for i,c in enumerate(PALETTE) if c[0] in ('A6','A7','A8','A9','B1','B2','B3')]
GREEN_IDS=[i for i,c in enumerate(PALETTE) if c[0] in ('C3','C4','C5')]
def nearest_pal_lab(lab):
    cand=range(len(PALETTE))
    L,a,b=lab
    if a>b+5 and math.hypot(a,b)>18: cand=RED_IDS      # 红系只选红/粉色号
    elif a<-6 and math.hypot(a,b)>20: cand=GREEN_IDS   # 绿系只选绿色号
    best=min(cand,key=lambda i:(lab[0]-PAL_LAB[i][0])**2+(lab[1]-PAL_LAB[i][1])**2+(lab[2]-PAL_LAB[i][2])**2)
    return best

# ---------- 1. 降采样：每格取中位代表像素(medoid)，保住细的红色镜框/绿叶 ----------
im=Image.open(SRC).convert('RGB'); iW,iH=im.size
W=72; H=round(W*iH/iW)
cw,ch=iW/W, iH/H
big=im.load()
def cell_color(cx,cy):
    x0=int(cx*cw); x1=max(x0+1,int((cx+1)*cw)); y0=int(cy*ch); y1=max(y0+1,int((cy+1)*ch))
    pts=[]
    for i in range(5):
        for j in range(5):
            x=int(x0+(x1-x0-1)*i/4); y=int(y0+(y1-y0-1)*j/4)
            pts.append(big[x,y])
    pl=[rgb2lab(*p) for p in pts]
    best=0;bd=1e18
    for i,a in enumerate(pl):
        s=sum((a[0]-b[0])**2+(a[1]-b[1])**2+(a[2]-b[2])**2 for b in pl)
        if s<bd: bd=s;best=i
    return pts[best]
cell=Image.new('RGB',(W,H)); cp=cell.load()
for cy in range(H):
    for cx in range(W):
        cp[cx,cy]=cell_color(cx,cy)
im=cell; px=im.load()
labs=[[rgb2lab(*px[x,y]) for x in range(W)] for y in range(H)]

# ---------- 2. 边界双主色种子 + 泛洪抠背景（纹理感知：只吃平滑的背景） ----------
import statistics
lstd=[[0.]*W for _ in range(H)]
for y in range(H):
    for x in range(W):
        vs=[]
        for dy in(-1,0,1):
            for dx in(-1,0,1):
                nx,ny=min(max(x+dx,0),W-1),min(max(y+dy,0),H-1)
                vs.append(sum(px[nx,ny])/3)
        lstd[y][x]=statistics.pstdev(vs)
border=[labs[0][x] for x in range(W)]+[labs[H-1][x] for x in range(W)]+[labs[y][0] for y in range(1,H-1)]+[labs[y][W-1] for y in range(1,H-1)]
s0=border[0]; s1=border[len(border)//2]
for _ in range(6):
    a=[0.,0.,0.];b=[0.,0.,0.];na=nb=0
    for c in border:
        if dist(c,s0)<dist(c,s1): a=[a[i]+c[i] for i in range(3)];na+=1
        else: b=[b[i]+c[i] for i in range(3)];nb+=1
    if na: s0=[v/na for v in a]
    if nb: s1=[v/nb for v in b]
na=sum(1 for c in border if dist(c,s0)<dist(c,s1)); nb=len(border)-na
# 两个种子都试一遍泛洪，保留"主体最大"的那个（正确背景留下完整主体）
bgTol=28; seedTol=bgTol*bgTol*2.2; edgeMax=max(12,bgTol*0.6); edgeMax2=edgeMax*edgeMax
def flood(seed):
    b=[[False]*W for _ in range(H)]; st=[]
    def ok(x,y):
        return dist(labs[y][x],seed)<seedTol and lstd[y][x]<1.4  # 平滑才可能是背景
    def psh(x,y):
        if 0<=x<W and 0<=y<H and not b[y][x] and ok(x,y):
            b[y][x]=True; st.append((x,y))
    for x in range(W): psh(x,0); psh(x,H-1)
    for y in range(1,H-1): psh(0,y); psh(W-1,y)
    while st:
        x,y=st.pop()
        for nx,ny in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
            if 0<=nx<W and 0<=ny<H and not b[ny][nx]:
                if dist(labs[y][x],labs[ny][nx])>edgeMax2: continue
                if not ok(nx,ny): continue
                b[ny][nx]=True; st.append((nx,ny))
    # 最大非背景连通域
    best=0
    vis=[[False]*W for _ in range(H)]
    for y in range(H):
        for x in range(W):
            if b[y][x] or vis[y][x]: continue
            s=[(x,y)]; vis[y][x]=True; n=0
            while s:
                cx,cy=s.pop(); n+=1
                for nx,ny in ((cx-1,cy),(cx+1,cy),(cx,cy-1),(cx,cy+1)):
                    if 0<=nx<W and 0<=ny<H and not b[ny][nx] and not vis[ny][nx]:
                        vis[ny][nx]=True; s.append((nx,ny))
            best=max(best,n)
    return b,best
bgA,nA=flood(s0); bgB,nB=flood(s1)
if nA>=nB: bg=bgA; seed=s0
else: bg=bgB; seed=s1
if nA<0.3*W*H and nB<0.3*W*H:
    bg=[[False]*W for _ in range(H)]  # 抠图失败(特写图)：整图当作主体
    print("bg removal skipped (close-up)")
print("seed pick: mainA=%d mainB=%d"%(nA,nB))

# ---------- 3. 主体连通域筛选 ----------
comp=[[-1]*W for _ in range(H)]; nc=0; sizes=[]
for y in range(H):
    for x in range(W):
        if bg[y][x] or comp[y][x]>=0: continue
        cells=[]; s=[(x,y)]; comp[y][x]=nc
        while s:
            cx,cy=s.pop(); cells.append((cx,cy))
            for nx,ny in ((cx-1,cy),(cx+1,cy),(cx,cy-1),(cx,cy+1)):
                if 0<=nx<W and 0<=ny<H and not bg[ny][nx] and comp[ny][nx]<0:
                    comp[ny][nx]=nc; s.append((nx,ny))
        sizes.append(len(cells)); nc+=1
mx=max(sizes) if sizes else 0
# 每个连通域平均色：高饱和色小连通域(樱桃/绿叶)也保留
comp_sum=[[0.,0.,0.,0] for _ in range(nc)]
for y in range(H):
    for x in range(W):
        if not bg[y][x]:
            c=labs[y][x]; s=comp_sum[comp[y][x]]
            s[0]+=c[0];s[1]+=c[1];s[2]+=c[2];s[3]+=1
comp_acc=[False]*nc
for i in range(nc):
    if comp_sum[i][3]:
        comp_acc[i]=is_accent([v/comp_sum[i][3] for v in comp_sum[i][:3]])
keep=[[(not bg[y][x]) and (sizes[comp[y][x]]>=mx*0.15 or comp_acc[comp[y][x]]) for x in range(W)] for y in range(H)]
# 清扫残留的近背景灰白平滑点（中性、很亮、贴近背景色、无纹理）
for y in range(H):
    for x in range(W):
        if not keep[y][x]: continue
        c=labs[y][x]
        if c[0]>80 and math.hypot(c[1],c[2])<10 and dist(c,seed)<seedTol*0.35 and lstd[y][x]<2.5:
            keep[y][x]=False
# 灰白背景剥离：从边界泛洪所有"中性且亮"的格
vis=[[False]*W for _ in range(H)]; st2=[]
def neutral_bright(x,y):
    c=labs[y][x]; return c[0]>75 and math.hypot(c[1],c[2])<10
for x in range(W):
    for y in (0,H-1):
        if keep[y][x] and neutral_bright(x,y) and not vis[y][x]:
            vis[y][x]=True; st2.append((x,y))
for y in range(1,H-1):
    for x in (0,W-1):
        if keep[y][x] and neutral_bright(x,y) and not vis[y][x]:
            vis[y][x]=True; st2.append((x,y))
while st2:
    x,y=st2.pop()
    for nx,ny in ((x-1,y),(x+1,y),(x,y-1),(x,y+1)):
        if 0<=nx<W and 0<=ny<H and keep[ny][nx] and not vis[ny][nx] and neutral_bright(nx,ny):
            vis[ny][nx]=True; st2.append((nx,ny))
n_strip=sum(sum(row) for row in vis)
for y in range(H):
    for x in range(W):
        if vis[y][x]: keep[y][x]=False
print("gray strip cells:",n_strip)
grid=[[px[x,y] if keep[y][x] else None for x in range(W)] for y in range(H)]

# ---------- 4. autoCrop（主体连通域裁剪） ----------
seen=[[False]*W for _ in range(H)]; comps=[]
for y in range(H):
    for x in range(W):
        if grid[y][x] is None or seen[y][x]: continue
        cells=[]; s=[(x,y)]; seen[y][x]=True
        while s:
            cx,cy=s.pop(); cells.append((cx,cy))
            for nx,ny in ((cx-1,cy),(cx+1,cy),(cx,cy-1),(cx,cy+1)):
                if 0<=nx<W and 0<=ny<H and grid[ny][nx] is not None and not seen[ny][nx]:
                    seen[ny][nx]=True; s.append((nx,ny))
        comps.append(cells)
if comps:
    mx2=max(len(c) for c in comps); big=[c for c in comps if len(c)>=mx2*0.2]
    xs=[x for c in big for x,y in c]; ys=[y for c in big for x,y in c]
    x0=max(0,min(xs)-1);x1=min(W-1,max(xs)+1);y0=max(0,min(ys)-1);y1=min(H-1,max(ys)+1)
    grid=[[grid[y][x] for x in range(x0,x1+1)] for y in range(y0,y1+1)]; H=len(grid); W=len(grid[0])
    labs=[[rgb2lab(*c) if c else None for c in row] for row in grid]

# ---------- 5. 量化：红/绿高饱和格直接按色号锁定，其余 Lub k-means(K=12) ----------
samples=[(x,y,labs[y][x]) for y in range(H) for x in range(W) if grid[y][x] is not None]
acc_cells=[s for s in samples if is_accent(s[2])]
base=[s for s in samples if not is_accent(s[2])]
K=min(12,len(base))
centers=[base[0][2]]
while len(centers)<K:
    d2=[min(dist(c,ce) for ce in centers) for _,_,c in base]
    centers.append(base[max(range(len(d2)),key=lambda k:d2[k])][2])
for _ in range(12):
    assign=[]
    for _,_,c in base:
        assign.append(min(range(len(centers)),key=lambda i:dist(c,centers[i])))
    acc=[[0.,0.,0.,0] for _ in range(len(centers))]
    for (sx,sy,c),a in zip(base,assign):
        acc[a][0]+=c[0];acc[a][1]+=c[1];acc[a][2]+=c[2];acc[a][3]+=1
    for i in range(len(centers)):
        if acc[i][3]: centers[i]=[acc[i][0]/acc[i][3],acc[i][1]/acc[i][3],acc[i][2]/acc[i][3]]
gq=[[-1]*W for _ in range(H)]
for sx,sy,c in base:
    gq[sy][sx]=min(range(len(centers)),key=lambda i:dist(c,centers[i]))
# 高饱和格：整格直接落到最近的同色系色号，不被棕色平均
acc_ids={}
for sx,sy,c in acc_cells:
    p=nearest_pal_lab(c)
    if p not in acc_ids:
        acc_ids[p]=len(centers); centers.append(list(PAL_LAB[p]))
    gq[sy][sx]=acc_ids[p]
fixed_pal={cid:p for p,cid in acc_ids.items()}   # 高饱和簇直接锁定色号
NCENT=len(centers)
accent=[is_accent(ce) or (i>=K) for i,ce in enumerate(centers)]
print("clusters:",NCENT,"accent:",[i for i in range(NCENT) if accent[i]],"accent cells:",len(acc_cells))

# ---------- 6. 平滑 ×1（保护高饱和色 + 深色(眼睛)不被浅色吃掉） ----------
for _ in range(1):
    g2=[row[:] for row in gq]
    for y in range(H):
        for x in range(W):
            v=gq[y][x]
            cnt={}
            for dy in(-1,0,1):
                for dx in(-1,0,1):
                    nx,ny=x+dx,y+dy
                    if 0<=nx<W and 0<=ny<H:
                        u=gq[ny][nx]; cnt[u]=cnt.get(u,0)+1
            if not cnt: continue
            w=max(cnt,key=cnt.get)
            if v<0:
                if w<NCENT and accent[w] and cnt[w]<3: continue
                g2[y][x]=w
                continue
            if v==w: continue
            if accent[v]: continue                              # 饱和色：永不覆写
            if centers[v][0]<48 and (w>=NCENT or centers[w][0]>60): continue  # 深色保护
            g2[y][x]=w
    gq=g2

# ---------- 7. 孤立噪点清除(5x5) ----------
g2=[row[:] for row in gq]
for y in range(H):
    for x in range(W):
        v0=gq[y][x]
        if v0<0 or (v0<NCENT and accent[v0]): continue
        nb=0
        for dy in(-2,-1,0,1,2):
            for dx in(-2,-1,0,1,2):
                if dx or dy:
                    nx,ny=x+dx,y+dy
                    if 0<=nx<W and 0<=ny<H and gq[ny][nx]==gq[y][x]: nb+=1
        if not nb: g2[y][x]=-1
gq=g2

# ---------- 8. 左右对称：左半为基准整半镜像（绝对对称，眼镜/耳朵自动变正） ----------
for y in range(H):
    for x in range(W//2):
        a=gq[y][x]; b=gq[y][W-1-x]
        aa=(a>=0 and a<NCENT and accent[a]); ab=(b>=0 and b<NCENT and accent[b])
        if aa and not ab: gq[y][W-1-x]=a
        elif ab and not aa: gq[y][x]=b
        else: gq[y][W-1-x]=gq[y][x]
m={}
for y in range(H):
    for x in range(W):
        v=gq[y][x]
        if v>=0:
            if v not in m: m[v]=len(m)
            gq[y][x]=m[v]
NC=max((v for row in gq for v in row if v>=0), default=-1)+1
fixed_pal={m[k]:v for k,v in fixed_pal.items() if k in m}

# ---------- 9. 每簇代表色 → 调色板，同色号合并 ----------
idxsum=[[0.,0.,0.,0] for _ in range(NC)]
for y in range(H):
    for x in range(W):
        v=gq[y][x]
        if v>=0 and grid[y][x] is not None:
            c=grid[y][x]; idxsum[v][0]+=c[0];idxsum[v][1]+=c[1];idxsum[v][2]+=c[2];idxsum[v][3]+=1
counts=Counter(v for row in gq for v in row if v>=0)
pal_of={}
for v in range(NC):
    if idxsum[v][3]==0: pal_of[v]=None; continue
    if v in fixed_pal: pal_of[v]=fixed_pal[v]; continue   # 锁定色号不被均值改判
    rgb=(round(idxsum[v][0]/idxsum[v][3]),round(idxsum[v][1]/idxsum[v][3]),round(idxsum[v][2]/idxsum[v][3]))
    pal_of[v]=nearest_pal_lab(rgb2lab(*rgb))
# 合并同色号簇
remap={}
merged_pal={}
newid=0
for v in range(NC):
    p=pal_of[v]
    if p is None: remap[v]=-1; continue
    key=None
    for u,pp in ((u,pp) for u,pp in pal_of.items() if pp==p and u in remap and remap[u]>=0):
        key=remap[u]; break
    if key is None: key=newid; newid+=1; merged_pal[key]=p
    remap[v]=key
NC2=newid
gq=[[remap[v] if v>=0 else -1 for v in row] for row in gq]
cnt2=Counter(v for row in gq for v in row if v>=0)
small={v for v,c in cnt2.items() if c<6}
if small:
    for y in range(H):
        for x in range(W):
            if gq[y][x] in small:
                nb=Counter(gq[ny][nx] for dy in(-1,0,1) for dx in(-1,0,1)
                           if (dx or dy) and 0<=(nx:=x+dx)<W and 0<=(ny:=y+dy)<H
                           and gq[ny][nx]>=0 and gq[ny][nx] not in small)
                gq[y][x]=max(nb,key=nb.get) if nb else -1
    cnt2=Counter(v for row in gq for v in row if v>=0)
    fixed_pal={k:v for k,v in fixed_pal.items() if k not in small}
sum2={}
for y in range(H):
    for x in range(W):
        v=gq[y][x]
        if v>=0 and grid[y][x] is not None:
            c=grid[y][x]; s=sum2.setdefault(v,[0.,0.,0.,0]); s[0]+=c[0];s[1]+=c[1];s[2]+=c[2];s[3]+=1
used=[]
for v in range(NC2):
    if v not in sum2 or sum2[v][3]==0: continue
    rgb=(round(sum2[v][0]/sum2[v][3]),round(sum2[v][1]/sum2[v][3]),round(sum2[v][2]/sum2[v][3]))
    best=merged_pal.get(v) or nearest_pal_lab(rgb2lab(*rgb))
    used.append((v,PALETTE[best][0],PALETTE[best][1],PALETTE[best][2],cnt2[v]))

# ---------- 10. 渲染：白底圆豆 + 黑描边 + 浅红网格 + 图例 + 白边 ----------
ct=20; gw=W*ct; gh=H*ct
legrows=math.ceil(len(used)/8) if used else 0; legh=legrows*34+18
img=Image.new('RGB',(gw+PAD*2*ct,gh+legh+PAD*2*ct),'white'); d=ImageDraw.Draw(img)
ox=PAD*ct; oy=PAD*ct
colmap={u[0]:u[3] for u in used}
for y in range(H):
    for x in range(W):
        v=gq[y][x]
        if v<0: continue
        d.ellipse([ox+x*ct+2,oy+y*ct+2,ox+x*ct+ct-2,oy+y*ct+ct-2],fill=hex2rgb(colmap[v]))
d.line_width=max(2,round(ct*0.12))
for y in range(H):
    for x in range(W):
        if gq[y][x]<0: continue
        x0=ox+x*ct;y0=oy+y*ct;x1=x0+ct;y1=y0+ct
        if y==0 or gq[y-1][x]<0: d.line([x0,y0,x1,y0],fill='black')
        if y==H-1 or gq[y+1][x]<0: d.line([x0,y1,x1,y1],fill='black')
        if x==0 or gq[y][x-1]<0: d.line([x0,y0,x0,y1],fill='black')
        if x==W-1 or gq[y][x+1]<0: d.line([x1,y0,x1,y1],fill='black')
d.line_width=1
for x in range(W+1): d.line([ox+x*ct,oy,ox+x*ct,oy+gh],fill=(228,190,190))
for y in range(H+1): d.line([ox,oy+y*ct,ox+gw,oy+y*ct],fill=(228,190,190))
try: font=ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc",14)
except Exception: font=ImageFont.load_default()
ly=oy+gh+12
for i,u in enumerate(used):
    col=i%8; row=i//8; lx=10+col*108; yy=ly+row*34
    d.rectangle([lx,yy,lx+18,yy+18],fill=hex2rgb(u[3]),outline='#bbb')
    d.text((lx+24,yy+2),f"{u[1]} {u[2]}×{u[4]}",fill='#333',font=font)
img.save(OUT)
print("OK",OUT,"size",W,"x",H,"colors",len(used),"total",sum(u[4] for u in used))
for u in used: print(" ",u[1],u[2],u[4])
