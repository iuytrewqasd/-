# 拼豆图纸生成工具（Python 源码版）

把任意照片转成「拼豆 / 像素」图纸：自动降采样、抠背景、量化到固定色板，
渲染成带**色号图例**的 PNG（圆豆 + 黑描边 + 浅红网格 + 白边），方便照着拼。

## 环境要求
- Python 3.8 及以上
- 依赖库：`Pillow`（图像处理）

安装依赖：
```bash
pip install -r requirements.txt
```

## 三种使用方式

### 方式一：双击/命令行，弹出文件选择框（最简单）
```bash
python hamster_pattern.py
```
不传任何参数时，会弹出系统文件选择框让你挑一张图；
挑完自动在同目录生成 `<原图名>_拼豆图纸.png`。
（若环境无法弹框，则自动回退用内置的默认仓鼠图。）

### 方式二：命令行指定图片（适合批量 / 给别人脚本用）
```bash
python hamster_pattern.py -i "D:\照片\我的猫.webp"
python hamster_pattern.py -i "D:\照片\我的猫.webp" -o "D:\输出\猫拼豆.png"
```
- `-i / --input`：输入图片路径（png/jpg/jpeg/webp/bmp/gif 均可）
- `-o / --output`：输出 PNG 路径（不写则默认输出到输入图同目录）

### 方式三：当模块调用
```python
from hamster_pattern import generate
generate("D:/照片/我的猫.webp", "D:/输出/猫拼豆.png")
```

## 输出说明
- 图纸每个圆格 = 1 颗豆；底部图例列出用到的色号、颜色名、16 进制、使用数量。
- 色板为 30 色固定拼豆配色（白/黄/红/绿/蓝/紫等），坐标见脚本 `PALETTE`。

## 可调参数（脚本内）
- `W`：输出图纸宽度（格数），高度按比例算。默认 72。
- `PAD`：四周白色留边（格），默认 3。
- `PALETTE`：可替换为你的拼豆品牌实际色板。
