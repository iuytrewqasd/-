const DEFAULT_PALETTE = [
  ['白色', '#FCFCFC'], ['奶油色', '#F3E9C8'], ['黄色', '#F6D60F'], ['橙黄', '#F5A623'],
  ['橙色', '#F47B20'], ['蜜桃色', '#F7B98B'], ['腮红粉', '#F2A0A0'], ['红色', '#E2231A'],
  ['珊瑚红', '#FA5B4E'], ['锈红', '#B7410E'], ['棕褐', '#D2A76F'], ['棕色', '#7C4A21'],
  ['深棕', '#8E402A'], ['玫瑰红', '#C94C4C'], ['桃红', '#E12E77'], ['泡泡糖粉', '#F599B7'],
  ['浅粉', '#FBAFBA'], ['紫红', '#D0448E'], ['梅紫', '#8E4585'], ['紫色', '#7D4198'],
  ['紫罗兰', '#9B59B6'], ['薰衣草', '#C39FD9'], ['长春花蓝', '#8C90C8'], ['深蓝', '#1F3B9C'],
  ['蓝色', '#1E62B4'], ['牛仔蓝', '#4A72B8'], ['浅蓝', '#9DC3F0'], ['天蓝', '#29ABE2'],
  ['青绿', '#40BCB8'], ['薄荷绿', '#8ADBC6'], ['青柠绿', '#8CC63F'], ['绿色', '#3FA744'],
  ['亮绿', '#00A651'], ['三叶草', '#33B086'], ['鹦鹉绿', '#6CBE45'], ['常青', '#1B6B4A'],
  ['深绿', '#14593D'], ['石板灰', '#71828E'], ['灰色', '#939598'], ['烟灰', '#C8C9C7'],
  ['炭灰', '#414042'], ['黑色', '#231F20'],
  ['酒红', '#6B1F2A'], ['驼色', '#B98A5E'], ['藕粉', '#EBC7C2'],
  ['橄榄绿', '#6D7B3A'], ['深蓝灰', '#46566B'], ['深紫', '#5B2D6E'],
];

let PALETTE = [];
let BG_LAB = null; // 自动识别到的背景色（Lab），用于限定背景洪水只清真正的背景
let PIXEL_ART = false; // 输入本身已是像素图/拼豆图纸：跳过去光影与边缘增强，并过滤水印红字
const APP_VER = 73; // 与 index.html 的 app.js?v= 及角标保持一致
window.APP_VER = APP_VER; // 供 index.html 的自动刷新轮询脚本读取
if (document.getElementById('verBadge')) document.getElementById('verBadge').textContent = 'v' + APP_VER;

function makeEntry([name, hex]) {
  const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
  return { name, hex, rgb: [r, g, b], lab: srgb2lab(r, g, b) };
}

function genCodes(n) {
  const codes = [], L = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let li = 0; li < L.length && codes.length < n; li++)
    for (let num = 1; num <= 9 && codes.length < n; num++) codes.push(L[li] + num);
  return codes;
}

// 相对亮度（0~1），>0.55 用黑字否则白字
function lum(p) {
  return (0.299 * p.rgb[0] + 0.587 * p.rgb[1] + 0.114 * p.rgb[2]) / 255;
}

// 品牌色号查找：把 BRAND_COLORS 预处理成 Lab 距离可查的数组
const BRAND_LABS = (() => {
  if (typeof BRAND_COLORS === 'undefined') return [];
  return Object.entries(BRAND_COLORS).map(([hex, m]) => {
    const r = parseInt(hex.slice(0, 2), 16), g = parseInt(hex.slice(2, 4), 16), b = parseInt(hex.slice(4, 6), 16);
    return { hex, lab: srgb2lab(r, g, b), brands: m };
  });
})();

// 给定一个 hex，返回 BRAND_COLORS 里最近色的品牌色号 {MARD, COCO, mm, pp, mxw}
function nearestBrand(hex) {
  if (!BRAND_LABS.length) return null;
  const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
  const lab = srgb2lab(r, g, b);
  let best = null, bd = Infinity;
  for (const entry of BRAND_LABS) {
    const d = (lab[0] - entry.lab[0]) ** 2 + (lab[1] - entry.lab[1]) ** 2 + (lab[2] - entry.lab[2]) ** 2;
    if (d < bd) { bd = d; best = entry; }
  }
  return best ? best.brands : null;
}

function setPalette(list) {
  PALETTE = list.map(makeEntry);
  genCodes(PALETTE.length).forEach((c, i) => PALETTE[i].code = c);
  PALETTE.forEach(p => { p.brands = nearestBrand(p.hex); });
  const mc = $('maxColors');
  mc.max = PALETTE.length;
  mc.value = PALETTE.length;
  $('colorLabel').textContent = `全部 ${PALETTE.length} 色`;
}

function extractPalette(image) {
  const w = 120, h = Math.max(1, Math.round(120 * image.height / image.width));
  const off = document.createElement('canvas');
  off.width = w; off.height = h;
  const ctx = off.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(image, 0, 0, w, h);
  const d = ctx.getImageData(0, 0, w, h).data;
  const buckets = {};
  for (let i = 0; i < d.length; i += 4) {
    const key = `${d[i] >> 4},${d[i + 1] >> 4},${d[i + 2] >> 4}`;
    const b = buckets[key] || (buckets[key] = { r: 0, g: 0, b: 0, n: 0 });
    b.r += d[i]; b.g += d[i + 1]; b.b += d[i + 2]; b.n++;
  }
  const cands = Object.values(buckets)
    .sort((a, b) => b.n - a.n)
    .slice(0, 120)
    .map(b => {
      const r = Math.round(b.r / b.n), g = Math.round(b.g / b.n), bl = Math.round(b.b / b.n);
      return { rgb: [r, g, bl], lab: srgb2lab(r, g, bl) };
    });
  const picked = [];
  for (const c of cands) {
    if (picked.every(p => {
      const l = p.lab;
      return (c.lab[0] - l[0]) ** 2 + (c.lab[1] - l[1]) ** 2 + (c.lab[2] - l[2]) ** 2 > 100;
    })) picked.push(c);
    if (picked.length >= DEFAULT_PALETTE.length) break;
  }
  return picked.map((c, i) =>
    [`色卡${i + 1}`, '#' + c.rgb.map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase()]);
}

function srgb2lab(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const f = c => (c > 0.04045 ? Math.pow((c + 0.055) / 1.055, 2.4) : c / 12.92);
  r = f(r); g = f(g); b = f(b);
  let x = (r * 0.4124 + g * 0.3576 + b * 0.1805) / 0.95047;
  let y = r * 0.2126 + g * 0.7152 + b * 0.0722;
  let z = (r * 0.0193 + g * 0.1192 + b * 0.9505) / 1.08883;
  const k = c => (c > 0.008856 ? Math.cbrt(c) : 7.787 * c + 16 / 116);
  x = k(x); y = k(y); z = k(z);
  return [116 * y - 16, 500 * (x - y), 200 * (y - z)];
}

function nearest(lab, pool) {
  let best = 0, bestD = Infinity;
  for (let i = 0; i < pool.length; i++) {
    const p = pool[i].lab;
    const d = (lab[0] - p[0]) ** 2 + (lab[1] - p[1]) ** 2 + (lab[2] - p[2]) ** 2;
    if (d < bestD) { bestD = d; best = i; }
  }
  return best;
}

function drawImageHQ(image, w, h) {
  let sw = image.width, sh = image.height, src = image;
  while (sw > w * 2 && sh > h * 2) {
    const nw = Math.max(w, Math.floor(sw / 2)), nh = Math.max(h, Math.floor(sh / 2));
    const c = document.createElement('canvas');
    c.width = nw; c.height = nh;
    const x = c.getContext('2d');
    x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
    x.drawImage(src, 0, 0, nw, nh);
    src = c; sw = nw; sh = nh;
  }
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const x = c.getContext('2d');
  x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
  x.drawImage(src, 0, 0, w, h);
  return c;
}

function enhance(ctx, w, h, sat, sharp, edge) {
  const im = ctx.getImageData(0, 0, w, h);
  const d = im.data;
  if (sat !== 100) {
    const s = sat / 100;
    for (let i = 0; i < d.length; i += 4) {
      const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      d[i] = Math.max(0, Math.min(255, gray + (d[i] - gray) * s));
      d[i + 1] = Math.max(0, Math.min(255, gray + (d[i + 1] - gray) * s));
      d[i + 2] = Math.max(0, Math.min(255, gray + (d[i + 2] - gray) * s));
    }
  }
  if (edge > 0) {
    // 混合空间增强（拼豆版）：Sobel 提边 → 均值平滑成掩膜 → 只在边缘叠加拉普拉斯，纯色区保持原样
    const g = new Float32Array(w * h);
    for (let i = 0, j = 0; i < d.length; i += 4, j++)
      g[j] = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    const mag = new Float32Array(w * h);
    let mx = 0;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const xm = x > 0 ? x - 1 : 0, xp = x < w - 1 ? x + 1 : w - 1;
      const ym = y > 0 ? y - 1 : 0, yp = y < h - 1 ? y + 1 : h - 1;
      const gx = (g[ym * w + xp] + 2 * g[y * w + xp] + g[yp * w + xp])
               - (g[ym * w + xm] + 2 * g[y * w + xm] + g[yp * w + xm]);
      const gy = (g[yp * w + xm] + 2 * g[yp * w + x] + g[yp * w + xp])
               - (g[ym * w + xm] + 2 * g[ym * w + x] + g[ym * w + xp]);
      const m = Math.hypot(gx, gy);
      mag[y * w + x] = m;
      if (m > mx) mx = m;
    }
    if (mx > 0) {
      const mask = new Float32Array(w * h);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        let s = 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const nx = Math.min(w - 1, Math.max(0, x + dx)), ny = Math.min(h - 1, Math.max(0, y + dy));
          s += mag[ny * w + nx];
        }
        // 均值平滑后低梯度区域置 0：大片纯色不会被锐化出噪点
        mask[y * w + x] = Math.max(0, Math.min(1, s / 9 / mx - 0.28) / 0.72);
      }
      const k = edge * 1.6;
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const mk = mask[y * w + x];
        if (mk <= 0) continue;
        const xm = x > 0 ? x - 1 : 0, xp = x < w - 1 ? x + 1 : w - 1;
        const ym = y > 0 ? y - 1 : 0, yp = y < h - 1 ? y + 1 : h - 1;
        const lap = (g[ym * w + x] + g[yp * w + x] + g[y * w + xm] + g[y * w + xp]) - 4 * g[y * w + x];
        const amt = Math.max(-80, Math.min(80, lap * k * mk));
        const i = (y * w + x) * 4;
        for (let ch = 0; ch < 3; ch++) d[i + ch] = Math.max(0, Math.min(255, d[i + ch] + amt));
      }
    }
  } else if (sharp > 0) {
    const k = sharp / 100;
    const blur = new Uint8ClampedArray(d.length);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      for (let ch = 0; ch < 3; ch++) {
        let sum = 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const nx = Math.min(w - 1, Math.max(0, x + dx)), ny = Math.min(h - 1, Math.max(0, y + dy));
          sum += d[(ny * w + nx) * 4 + ch];
        }
        blur[(y * w + x) * 4 + ch] = sum / 9;
      }
    }
    for (let i = 0; i < d.length; i += 4) for (let ch = 0; ch < 3; ch++)
      d[i + ch] = Math.max(0, Math.min(255, d[i + ch] + (d[i + ch] - blur[i + ch]) * k));
  }
  ctx.putImageData(im, 0, 0);
}

const BRAND_NAMES = { MARD: 'MARD', COCO: 'COCO', mm: '漫漫', pp: '盼盼', mxw: '咪小窝' };
function currentBrand() { return $('brandSelect') ? $('brandSelect').value : 'MARD'; }
function brandCode(p) {
  const b = currentBrand();
  if (p.brands && p.brands[b] && p.brands[b] !== '-') return p.brands[b];
  return p.code;
}
const $ = id => document.getElementById(id);
let img = null, origImg = null, curName = '', grid = null, gw = 0, gh = 0;

$('dropzone').onclick = () => $('file').click();
$('dropzone').ondragover = e => { e.preventDefault(); $('dropzone').classList.add('hover'); };
$('dropzone').ondragleave = () => $('dropzone').removeAttribute('class');
$('dropzone').ondrop = e => {
  e.preventDefault(); $('dropzone').removeAttribute('class');
  if (e.dataTransfer.files[0]) loadFile(e.dataTransfer.files[0]);
};
$('file').onchange = e => { if (e.target.files[0]) loadFile(e.target.files[0]); };

function loadFile(file) {
  curName = file.name;
  const reader = new FileReader();
  reader.onload = () => {
    const im = new Image();
    im.onload = () => {
      origImg = im;
      if ($('autoCropOn').checked) autoCrop();
      else setContent(im);
    };
    im.src = reader.result;
  };
  reader.readAsDataURL(file);
}

function setContent(src) {
  img = src;
  $('dropzone').textContent = `✅ ${curName} (${img.width}×${img.height})`;
  $('autoSize').click(); // 导入/裁剪后自动应用智能尺寸（长边顶满 50）
}

// 细节密集区检测：按梯度能量找最大连通块，用于截图类图片（上下夹 UI/黑边）定位画面主体
function denseBBox(w, h, gray) {
  const N = 48, cellPx = Math.max(w, h) / N;
  const gw = Math.max(3, Math.round(w / cellPx)), gh = Math.max(3, Math.round(h / cellPx));
  const at = (x, y) => gray[Math.min(h - 1, Math.round((y + 0.5) * cellPx)) * w + Math.min(w - 1, Math.round((x + 0.5) * cellPx))];
  const e = [];
  let mx = 0;
  for (let y = 0; y < gh; y++) {
    const row = [];
    for (let x = 0; x < gw; x++) {
      let v = 0;
      if (x > 0 && x < gw - 1 && y > 0 && y < gh - 1)
        v = Math.abs(at(x + 1, y) - at(x - 1, y)) + Math.abs(at(x, y + 1) - at(x, y - 1));
      row.push(v);
      if (v > mx) mx = v;
    }
    e.push(row);
  }
  if (mx <= 0) return null;
  const thr = mx * 0.18;
  const seen = new Uint8Array(gw * gh);
  let best = null;
  for (let sy = 0; sy < gh; sy++) for (let sx = 0; sx < gw; sx++) {
    if (seen[sy * gw + sx] || e[sy][sx] <= thr) continue;
    const q = [sx, sy], comp = [];
    seen[sy * gw + sx] = 1;
    while (q.length) {
      const y = q.pop(), x = q.pop();
      comp.push(x, y);
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
        if (seen[ny * gw + nx] || e[ny][nx] <= thr) continue;
        seen[ny * gw + nx] = 1;
        q.push(nx, ny);
      }
    }
    if (!best || comp.length > best.length) best = comp;
  }
  if (!best) return null;
  let x0 = 1e9, x1 = -1, y0 = 1e9, y1 = -1;
  for (let i = 0; i < best.length; i += 2) {
    x0 = Math.min(x0, best[i]); x1 = Math.max(x1, best[i]);
    y0 = Math.min(y0, best[i + 1]); y1 = Math.max(y1, best[i + 1]);
  }
  const pad = Math.round(cellPx);
  return {
    x0: Math.max(0, Math.round(x0 * cellPx) - pad),
    y0: Math.max(0, Math.round(y0 * cellPx) - pad),
    x1: Math.min(w - 1, Math.round((x1 + 1) * cellPx) + pad),
    y1: Math.min(h - 1, Math.round((y1 + 1) * cellPx) + pad),
  };
}

function autoCrop() {
  if (!origImg) return;
  const S = 256;
  const sc = Math.min(1, S / Math.max(origImg.width, origImg.height));
  const w = Math.max(1, Math.round(origImg.width * sc));
  const h = Math.max(1, Math.round(origImg.height * sc));
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const x = c.getContext('2d', { willReadFrequently: true });
  x.drawImage(origImg, 0, 0, w, h);
  const d = x.getImageData(0, 0, w, h).data;
  const gray = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) gray[i] = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2];
  const cb = 6;
  let br = 0, bgc = 0, bbc = 0, n = 0;
  for (const [cy, cx] of [[0, 0], [0, w - cb], [h - cb, 0], [h - cb, w - cb]])
    for (let y = cy; y < cy + cb; y++) for (let px = cx; px < cx + cb; px++) {
      const i = (y * w + px) * 4;
      br += d[i]; bgc += d[i + 1]; bbc += d[i + 2]; n++;
    }
  br /= n; bgc /= n; bbc /= n;
  const mask = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) for (let px = 0; px < w; px++) {
    const i = y * w + px;
    const dr = d[i * 4] - br, dg = d[i * 4 + 1] - bgc, db = d[i * 4 + 2] - bbc;
    let g = 0;
    if (px > 0 && y > 0 && px < w - 1 && y < h - 1)
      g = Math.abs(gray[i + 1] - gray[i - 1]) + Math.abs(gray[i + w] - gray[i - w]);
    if (dr * dr + dg * dg + db * db > 1600 || g > 24) mask[i] = 1;
  }
  const rowT = Math.max(1, Math.round(w * 0.01));
  const colT = Math.max(1, Math.round(h * 0.01));
  let top = -1, bot = -1, left = -1, right = -1;
  for (let y = 0; y < h; y++) {
    let ct = 0;
    for (let px = 0; px < w; px++) ct += mask[y * w + px];
    if (ct >= rowT) { if (top < 0) top = y; bot = y; }
  }
  for (let px = 0; px < w; px++) {
    let ct = 0;
    for (let y = 0; y < h; y++) ct += mask[y * w + px];
    if (ct >= colT) { if (left < 0) left = px; right = px; }
  }
  const full = top >= 0 && (bot - top + 1) >= h * 0.98 && (right - left + 1) >= w * 0.98;
  let bx0 = left, by0 = top, bx1 = right, by1 = bot;
  if (top < 0 || left < 0 || full) {
    // 整幅都是内容时（如手机相册截图，上下夹着 UI 和黑边）：改按“细节最密集的连通块”定位主体
    const b = denseBBox(w, h, gray);
    if (b && (b.x1 - b.x0 + 1) * (b.y1 - b.y0 + 1) < w * h * 0.8) {
      bx0 = b.x0; by0 = b.y0; bx1 = b.x1; by1 = b.y1;
    } else {
      setContent(origImg);
      $('cropTip').textContent = '未检测到多余背景，保留原图';
      return;
    }
  }
  const padX = Math.round((bx1 - bx0) * 0.02), padY = Math.round((by1 - by0) * 0.02);
  const sx = Math.max(0, Math.floor((bx0 - padX) / sc));
  const sy = Math.max(0, Math.floor((by0 - padY) / sc));
  const sw = Math.min(origImg.width - sx, Math.ceil((bx1 - bx0 + 1 + padX * 2) / sc));
  const sh = Math.min(origImg.height - sy, Math.ceil((by1 - by0 + 1 + padY * 2) / sc));
  const cc = document.createElement('canvas');
  cc.width = sw; cc.height = sh;
  cc.getContext('2d').drawImage(origImg, sx, sy, sw, sh, 0, 0, sw, sh);
  setContent(cc);
  const cut = Math.round(100 * (1 - (sw * sh) / (origImg.width * origImg.height)));
  $('cropTip').textContent = `✂ 已裁剪 ${origImg.width}×${origImg.height} → ${sw}×${sh}，去除约 ${cut}% 多余背景`;
}

$('autoCrop').onclick = autoCrop;
$('cropReset').onclick = () => {
  if (!origImg) return;
  setContent(origImg);
  $('cropTip').textContent = '已还原为原图';
};

function applyRatio() {
  if (!img || !$('ratio').checked) return;
  const w = Math.min(200, Math.max(1, +$('w').value || 29));
  $('w').value = w;
  $('h').value = Math.min(200, Math.max(1, Math.round(w * img.height / img.width)));
}
$('w').oninput = applyRatio;
$('ratio').onchange = applyRatio;
[['sharpen', 'sharpLabel'], ['saturation', 'satLabel'], ['edgeStrength', 'edgeLabel']].forEach(([id, lab]) => {
  $(id).oninput = () => $(lab).textContent = $(id).value + '%';
});
document.querySelectorAll('.presets button[data-w]').forEach(b =>
  b.onclick = () => { $('w').value = b.dataset.w; $('h').value = b.dataset.h; });

// 智能色号数：按覆盖率取最少够用的色号，并保留紧凑成形的细节色块（眼睛、镜框等）
function recommendColors(w, h, minC) {
  minC = minC || 6;
  const c = drawImageHQ(img, w, h);
  const d = c.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, w, h).data;
  const n = w * h;
  const cells = new Int16Array(n).fill(-1);
  const count = new Map();
  let total = 0;
  for (let i = 0, j = 0; i < d.length; i += 4, j++) {
    if (d[i + 3] < 128) continue;
    const pi = nearest(srgb2lab(d[i], d[i + 1], d[i + 2]), PALETTE);
    cells[j] = pi;
    count.set(pi, (count.get(pi) || 0) + 1);
    total++;
  }
  if (!total) return Math.min(8, PALETTE.length);
  const order = [...count.entries()].sort((a, b) => b[1] - a[1]);
  let acc = 0, n98 = 0;
  for (const [, k] of order) {
    acc += k; n98++;
    if (acc >= total * 0.98) break;
  }
  const kept = new Set(order.slice(0, n98).map(e => e[0]));
  const seen = new Uint8Array(n);
  for (const [pi] of order.slice(n98)) {
    let blob = false;
    for (let i = 0; i < n && !blob; i++) {
      if (cells[i] !== pi || seen[i]) continue;
      const q = [i];
      seen[i] = 1;
      let size = 0;
      while (q.length) {
        const k = q.pop();
        size++;
        if (size >= 6) { blob = true; break; }
        const x = k % w, y = (k - x) / w;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = x + dx, ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
          const j = ny * w + nx;
          if (cells[j] === pi && !seen[j]) { seen[j] = 1; q.push(j); }
        }
      }
    }
    if (blob) kept.add(pi);
  }
  return Math.max(minC, Math.min(32, Math.min(PALETTE.length, kept.size)));
}

// 去光影：用大半径模糊估计局部光照强度，再从每个像素里减去，
// 压平明暗渐变（阴影、高光、渐晕），只保留物体本身的颜色与边缘
function flattenLighting(data, w, h) {
  const n = w * h, lum = new Float32Array(n);
  let sum = 0, cnt = 0;
  for (let i = 0; i < n; i++) {
    if (data[i * 4 + 3] < 128) continue;
    const l = 0.299 * data[i * 4] + 0.587 * data[i * 4 + 1] + 0.114 * data[i * 4 + 2];
    lum[i] = l; sum += l; cnt++;
  }
  if (!cnt) return;
  const mean = sum / cnt;
  for (let i = 0; i < n; i++) if (data[i * 4 + 3] < 128) lum[i] = mean;
  const r = Math.max(4, Math.round(Math.min(w, h) / 8));
  const tmp = new Float32Array(n), blur = new Float32Array(n);
  const span = 2 * r + 1;
  for (let y = 0; y < h; y++) {
    let acc = 0;
    for (let x = -r; x <= r; x++) acc += lum[y * w + Math.min(w - 1, Math.max(0, x))];
    for (let x = 0; x < w; x++) {
      tmp[y * w + x] = acc / span;
      acc += lum[y * w + Math.min(w - 1, x + r + 1)] - lum[y * w + Math.max(0, x - r)];
    }
  }
  for (let x = 0; x < w; x++) {
    let acc = 0;
    for (let y = -r; y <= r; y++) acc += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
    for (let y = 0; y < h; y++) {
      blur[y * w + x] = acc / span;
      acc += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x];
    }
  }
  const k = 0.9;
  for (let i = 0; i < n; i++) {
    if (data[i * 4 + 3] < 128) continue;
    let delta = -(blur[i] - mean) * k;
    delta = Math.max(-45, Math.min(45, delta));
    for (let ch = 0; ch < 3; ch++) {
      const v = data[i * 4 + ch] + delta;
      data[i * 4 + ch] = v < 0 ? 0 : v > 255 ? 255 : v;
    }
  }
}

// 判断一张图是否以"近黑"颜色为主（如 demo12 黑底红图）。近黑背景的图不当作"已有图纸"，
// 否则会被误关边缘增强、糊成一坨。真正的拼豆图纸几乎都是白底/浅底。
function isDarkDominant(src) {
  if (!src) return false;
  const n = document.createElement('canvas');
  n.width = 128; n.height = 128;
  const nx = n.getContext('2d', { willReadFrequently: true });
  nx.imageSmoothingEnabled = false;
  nx.drawImage(src, 0, 0, 128, 128);
  const p = nx.getImageData(0, 0, 128, 128).data;
  const b = new Map();
  let op = 0;
  for (let i = 0; i < p.length; i += 4) {
    if (p[i + 3] < 128) continue;
    op++;
    const k = (p[i] >> 4) << 8 | (p[i + 1] >> 4) << 4 | (p[i + 2] >> 4);
    b.set(k, (b.get(k) || 0) + 1);
  }
  if (!op) return false;
  const top = [...b.entries()].sort((a, c) => c[1] - a[1])[0][0];
  const r = ((top >> 8) & 0xf) * 16, g = ((top >> 4) & 0xf) * 16, bl = (top & 0xf) * 16;
  return r < 48 && g < 48 && bl < 48;
}

$('autoSize').onclick = () => {
  if (!img) { alert('请先导入图片'); return; }
  const c = document.createElement('canvas');
  c.width = 64; c.height = 64;
  const x = c.getContext('2d', { willReadFrequently: true });
  x.drawImage(img, 0, 0, 64, 64);
  const d = x.getImageData(0, 0, 64, 64).data;
  const gray = i => 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
  let grad = 0, edgeHits = 0;
  for (let y = 1; y < 63; y++) for (let px = 1; px < 63; px++) {
    const i = (y * 64 + px) * 4;
    const g = Math.abs(gray(i + 4) - gray(i)) + Math.abs(gray(i + 256) - gray(i));
    grad += g;
    if (g > 60) edgeHits++;
  }
  grad /= 62 * 62;
  // 强边缘占比：细线 logo 色数少但线条密，该值高；扁平大色块卡通该值低
  const edgeShare = edgeHits / (62 * 62);
  // 自动匹配增强参数：按压缩后的色数粗分图片类型，选一个不用手动调的强度
  const colorSet = new Set();
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] < 128) continue;
    colorSet.add((d[i] >> 4) << 8 | (d[i + 1] >> 4) << 4 | (d[i + 2] >> 4));
  }
  const colors = colorSet.size;
  // 像素图/已有图纸/扁平插画检测：最近邻缩到 128² 保留硬边后，统计 Top8 色桶覆盖的像素占比。
  // 实测：图纸截图 0.91、照片 0.43（相邻同色、色桶总数都受 JPEG 噪声/皮肤渐变干扰，区分度不足）。
  // 这类图的腮红/高光/阴影是设计色块而非光照，去光影会误抹、边缘增强会炸出噪点，两者都要关
  const nn = document.createElement('canvas');
  nn.width = 128; nn.height = 128;
  const nx2 = nn.getContext('2d', { willReadFrequently: true });
  nx2.imageSmoothingEnabled = false;
  nx2.drawImage(img, 0, 0, 128, 128);
  const nd = nx2.getImageData(0, 0, 128, 128).data;
  const buckets = new Map();
  let opaqueN = 0;
  for (let i = 0; i < nd.length; i += 4) {
    if (nd[i + 3] < 128) continue;
    opaqueN++;
    const key = (nd[i] >> 4) << 8 | (nd[i + 1] >> 4) << 4 | (nd[i + 2] >> 4);
    buckets.set(key, (buckets.get(key) || 0) + 1);
  }
  const top8 = [...buckets.values()].sort((a, b) => b - a).slice(0, 8).reduce((s, v) => s + v, 0);
  // 近黑背景（如 demo12 黑底红图）不算"已有图纸"：原图或裁剪后图任一以近黑为主都判为非像素图，
  // 否则会被误关边缘增强、糊成一坨，且多余的红色水印过滤也会跑。真正的拼豆图纸几乎都是白底/浅底。
  // 注意 autoCrop 会把黑底裁掉，所以必须用原图 origImg 兜底判断。
  const darkBg = isDarkDominant(img) || isDarkDominant(origImg);
  PIXEL_ART = opaqueN > 0 && top8 / opaqueN > 0.7 && !darkBg;
  // 手动图片类型覆盖：用户可强制指定，避免自动检测误判（如 demo12 黑底红图被误判成"已有图纸"）
  if ($('imgType')) {
    const t = $('imgType').value;
    if (t === 'art') PIXEL_ART = false;
    else if (t === 'blueprint') PIXEL_ART = true;
  }
  const kind = PIXEL_ART ? '像素图/已有图纸' : colors <= 24 ? '图标/线稿类' : colors <= 300 ? '插画/图表类' : '照片类';
  const strength = colors <= 24 ? 70 : colors <= 300 ? 55 : 45;
  $('edgeEnhance').checked = !PIXEL_ART;
  // 去光影默认开启，仅像素图关闭；上次检测为像素图时关掉的状态要在换回照片时恢复
  if ($('deLight')) $('deLight').checked = !PIXEL_ART;
  $('edgeStrength').value = strength;
  $('edgeLabel').textContent = strength + '%';
  // 纯色背景自动识别：四角颜色相近（每通道差 ≤1）且该色占画面 25% 以上，就自动勾选“跳过纯色背景”
  const q4 = i => [d[i] >> 4, d[i + 1] >> 4, d[i + 2] >> 4];
  const near = (p, r) => Math.abs(p[0] - r[0]) <= 1 && Math.abs(p[1] - r[1]) <= 1 && Math.abs(p[2] - r[2]) <= 1;
  const c00 = q4(0), c10 = q4(63 * 4), c01 = q4(63 * 64 * 4), c11 = q4((63 * 64 + 63) * 4);
  let bgShare = 0;
  if (near(c00, c10) && near(c00, c01) && near(c00, c11)) {
    let hit = 0, all = 0;
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] < 128) continue;
      all++;
      if (near(q4(i), c00)) hit++;
    }
    bgShare = all ? hit / all : 0;
  }
  const autoBg = bgShare >= 0.25;
  // 标准模式：白底默认留空（与 skipBlack 对称）。若导入的是黑底/深色图，用户可手动取消勾选。
  $('skipWhite').checked = true;
  BG_LAB = autoBg ? srgb2lab(c00[0] * 16 + 8, c00[1] * 16 + 8, c00[2] * 16 + 8) : null;
  // 标准模式：默认开启去噪，消除孤立杂点豆子（图标/插画/照片都受益，不再仅限照片）
  $('denoise').checked = true;
  // 智能推荐：默认长边 100 格（细节足够还原）；原图不足 100 像素时不放大，
  // 极简图标适当降到 72 格以减少豆子数量；宽高始终可在 1~200 内手动修改
  const maxDim = Math.max(img.width, img.height);
  let long = 100;
  if (maxDim < 100) long = maxDim;
  else if (grad < 8 && edgeShare < 0.06) long = 72; // 细线多的图（edgeShare 高）不许降格，白线比格子还窄会丢
  long = Math.min(200, Math.max(1, Math.round(long)));
  let w, h;
  if (img.width >= img.height) {
    w = long;
    h = Math.round(long * img.height / img.width);
  } else {
    h = long;
    w = Math.round(long * img.width / img.height);
  }
  w = Math.min(200, Math.max(1, w));
  h = Math.min(200, Math.max(1, h));
  $('w').value = w; $('h').value = h;
  const autoColors = recommendColors(w, h, colors > 300 ? 12 : 8);
  $('maxColors').value = autoColors;
  $('colorLabel').textContent = `最多 ${autoColors} 色`;
  const bgTip = autoBg ? `画面纯色背景占 ${Math.round(bgShare * 100)}%，已自动勾选「跳过纯色背景」。` : '';
  const enhanceTip = PIXEL_ART
    ? '已自动关闭边缘增强与去光影（图纸的腮红/高光是色块而非光照），并已过滤小面积红色水印字。'
    : `已自动开启边缘增强 ${strength}%，`;
  $('sizeTip').textContent = `推荐 ${w}×${h}（长边 ${long} 格，保持原图比例；宽高可在 1~200 之间手动修改）。检测为${kind}，${enhanceTip}颜色上限推荐 ${autoColors} 色。${bgTip}想更整块可再调低色号，想更细腻可调高。`;
  $('sizeTip').hidden = false;
};

$('maxColors').oninput = e => {
  const v = +e.target.value;
  $('colorLabel').textContent = v >= PALETTE.length ? `全部 ${PALETTE.length} 色` : `最多 ${v} 色`;
};

if ($('mergeThresh')) $('mergeThresh').oninput = e => {
  const v = +e.target.value;
  $('mergeLabel').textContent = v === 0 ? '关闭' : `${v}%`;
};

if ($('brandSelect')) $('brandSelect').onchange = () => { if (grid) render(); };
if ($('bgDark')) $('bgDark').onchange = () => { if (grid) render(); };
if ($('showCodes')) $('showCodes').onchange = () => { if (grid) render(); };
if ($('imgType')) $('imgType').onchange = () => { if (img) $('autoSize').click(); };
if ($('zoom')) $('zoom').oninput = applyZoom;

$('generate').onclick = generate;

function generate() {
  if (!img) { alert('请先导入图片'); return; }
  gw = Math.min(200, Math.max(1, +$('w').value || 29));
  gh = Math.min(200, Math.max(1, +$('h').value || 29));
  $('w').value = gw; $('h').value = gh;
  const ctx = drawImageHQ(img, gw, gh).getContext('2d', { willReadFrequently: true });
  // 增强/去光影处理前的原始均值，用于计算处理偏移（主导色采样时保留这些效果）
  const rawGrid = ctx.getImageData(0, 0, gw, gh).data;
  // 每格深色覆盖率 + 格内最暗像素亮度：黑线缩放后会被平均成灰色，凭这两项判回纯黑
  // 同时收集每格 4×4 样本，用 medoid（与其他样本距离和最小的真实像素）作该格代表色：
  // 均值会把两种颜色混成不存在的灰/泥色，medoid 永远落在真实像素上且不受离群点影响
  const cover = new Float32Array(gw * gh);
  const wcover = new Float32Array(gw * gh);
  const minL = new Float32Array(gw * gh).fill(255);
  const dominant = new Uint8ClampedArray(gw * gh * 3);
  const hasDom = new Uint8Array(gw * gh);
  {
    const c4 = drawImageHQ(img, gw * 4, gh * 4);
    const d4 = c4.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, gw * 4, gh * 4).data;
    const samp = new Uint8ClampedArray(16 * 3);
    for (let cy = 0; cy < gh; cy++) for (let cx = 0; cx < gw; cx++) {
      const j = cy * gw + cx;
      let n = 0;
      for (let ty = 0; ty < 4; ty++) for (let tx = 0; tx < 4; tx++) {
        const x = cx * 4 + tx, y = cy * 4 + ty;
        const i = (y * gw * 4 + x) * 4;
        if (d4[i + 3] < 128) continue;
        const r = d4[i], g = d4[i + 1], b = d4[i + 2];
        const l = 0.299 * r + 0.587 * g + 0.114 * b;
        if (l < 60) cover[j]++;
        if (l > 235) wcover[j]++;
        if (l < minL[j]) minL[j] = l;
        samp[n * 3] = r; samp[n * 3 + 1] = g; samp[n * 3 + 2] = b;
        n++;
      }
      if (n > 0) {
        let bi = 0, bs = Infinity;
        for (let a = 0; a < n; a++) {
          const ar = samp[a * 3], ag = samp[a * 3 + 1], ab = samp[a * 3 + 2];
          let s = 0;
          for (let b2 = 0; b2 < n; b2++) {
            const dr = ar - samp[b2 * 3], dg = ag - samp[b2 * 3 + 1], db = ab - samp[b2 * 3 + 2];
            s += dr * dr + dg * dg + db * db;
          }
          if (s < bs) { bs = s; bi = a; }
        }
        dominant[j * 3] = samp[bi * 3];
        dominant[j * 3 + 1] = samp[bi * 3 + 1];
        dominant[j * 3 + 2] = samp[bi * 3 + 2];
        hasDom[j] = 1;
      }
      cover[j] /= 16;
    }
  }
  const lineArt = $('lineart').checked;
  if (lineArt) {
    // 线稿模式：先二值化再量化，避免细线条被缩放平均成灰阶碎块
    const raw = ctx.getImageData(0, 0, gw, gh);
    const d0 = raw.data;
    for (let i = 0; i < gw * gh; i++) {
      const lum = 0.299 * d0[i * 4] + 0.587 * d0[i * 4 + 1] + 0.114 * d0[i * 4 + 2];
      const v = lum < 205 ? 0 : 255; // 205≈该格黑色覆盖率 20%，偏低阈值保住细线连续性
      d0[i * 4] = d0[i * 4 + 1] = d0[i * 4 + 2] = v;
    }
    ctx.putImageData(raw, 0, 0);
  } else {
    enhance(ctx, gw, gh, +$('saturation').value, +$('sharpen').value,
      $('edgeEnhance').checked ? +$('edgeStrength').value / 100 : 0);
  }
  const data = ctx.getImageData(0, 0, gw, gh).data;
  if ($('deLight') && $('deLight').checked) flattenLighting(data, gw, gh);

  // Medoid 采样：用格内最具代表性的真实像素色替换均值，再叠加处理偏移（去光影/饱和度/边缘增强的差值），
  // 这样既去掉均值造成的灰边与串色，又保留原有增强效果。线稿模式走二值化，不参与
  if ($('dominant') && $('dominant').checked && !lineArt) {
    for (let i = 0; i < gw * gh; i++) {
      if (!hasDom[i] || data[i * 4 + 3] < 128) continue;
      // 黑线横跨亮底时 medoid 必取多数派的亮色、丢弃少数派黑线（少数派距离和必输），
      // 导致粗线断成虚线。这类格保持均值灰，交给后面的黑色保护判回纯黑
      if (cover[i] >= 0.18 && minL[i] <= 32) {
        const q0 = i * 3;
        const dl = 0.299 * dominant[q0] + 0.587 * dominant[q0 + 1] + 0.114 * dominant[q0 + 2];
        if (dl > 72) continue;
      }
      // 白线横跨深色底是反向情形：medoid 必取多数派深色、丢弃少数派白线（拳头/闪电被吞成红剪影）。
      // 这类格保持均值色，交给后面的白线保护判回纯白
      if (wcover[i] >= 0.18 && cover[i] < 0.18) {
        const q0 = i * 3;
        const dl = 0.299 * dominant[q0] + 0.587 * dominant[q0 + 1] + 0.114 * dominant[q0 + 2];
        if (dl < 150) continue;
      }
      const p = i * 4, q = i * 3;
      for (let ch = 0; ch < 3; ch++) {
        const delta = data[p + ch] - rawGrid[p + ch];
        data[p + ch] = Math.max(0, Math.min(255, dominant[q + ch] + delta));
      }
    }
  }

  if ($('symmetric').checked) {
    for (let y = 0; y < gh; y++) for (let x = 0; x < gw >> 1; x++) {
      const i = (y * gw + x) * 4, j = (y * gw + (gw - 1 - x)) * 4;
      for (let ch = 0; ch < 4; ch++) data[i + ch] = data[j + ch] = (data[i + ch] + data[j + ch]) / 2;
    }
  }

  const labs = new Float32Array(gw * gh * 3);
  grid = new Int16Array(gw * gh);
  for (let i = 0; i < gw * gh; i++) {
    const a = data[i * 4 + 3];
    if (a < 128) { grid[i] = -1; continue; }
    const l = srgb2lab(data[i * 4], data[i * 4 + 1], data[i * 4 + 2]);
    labs[i * 3] = l[0]; labs[i * 3 + 1] = l[1]; labs[i * 3 + 2] = l[2];
  }

  if ($('kmeans').checked) {
    const n = gw * gh, k = Math.min(12, PALETTE.length, +$('maxColors').value || 12);
    const order = [...Array(n).keys()].sort((a, b) => labs[a * 3] - labs[b * 3]);
    const centers = [];
    for (let c = 0; c < k; c++) {
      const j = order[Math.floor((c + 0.5) * n / k)] * 3;
      centers.push([labs[j], labs[j + 1], labs[j + 2]]);
    }
    const assign = new Int16Array(n);
    for (let it = 0; it < 10; it++) {
      for (let i = 0; i < n; i++) {
        let best = 0, bd = Infinity;
        for (let c = 0; c < k; c++) {
          const dd = (labs[i * 3] - centers[c][0]) ** 2 + (labs[i * 3 + 1] - centers[c][1]) ** 2 + (labs[i * 3 + 2] - centers[c][2]) ** 2;
          if (dd < bd) { bd = dd; best = c; }
        }
        assign[i] = best;
      }
      const sum = Array.from({ length: k }, () => [0, 0, 0, 0]);
      for (let i = 0; i < n; i++) {
        const s = sum[assign[i]];
        s[0] += labs[i * 3]; s[1] += labs[i * 3 + 1]; s[2] += labs[i * 3 + 2]; s[3]++;
      }
      for (let c = 0; c < k; c++) if (sum[c][3])
        centers[c] = [sum[c][0] / sum[c][3], sum[c][1] / sum[c][3], sum[c][2] / sum[c][3]];
    }
    const mapped = centers.map(c => nearest(c, PALETTE));
    for (let i = 0; i < n; i++) grid[i] = mapped[assign[i]];
  } else if ($('dither').checked) {
    // 抖动是独立的量化方式，不与 k-means 叠加（叠加会打散聚类产生噪点）
    const err = new Float32Array(gw * gh * 3);
    for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) {
      const i = y * gw + x;
      if (grid[i] === -1) continue;
      const cur = [labs[i * 3] + err[i * 3], labs[i * 3 + 1] + err[i * 3 + 1], labs[i * 3 + 2] + err[i * 3 + 2]];
      const pi = nearest(cur, PALETTE);
      grid[i] = pi;
      const p = PALETTE[pi].lab;
      const e = [cur[0] - p[0], cur[1] - p[1], cur[2] - p[2]];
      const push = (nx, ny, w) => {
        if (nx < 0 || nx >= gw || ny >= gh) return;
        const j = ny * gw + nx;
        err[j * 3] += e[0] * w; err[j * 3 + 1] += e[1] * w; err[j * 3 + 2] += e[2] * w;
      };
      push(x + 1, y, 7 / 16); push(x - 1, y + 1, 3 / 16); push(x, y + 1, 5 / 16); push(x + 1, y + 1, 1 / 16);
    }
  } else {
    for (let i = 0; i < gw * gh; i++)
      if (grid[i] !== -1) grid[i] = nearest([labs[i * 3], labs[i * 3 + 1], labs[i * 3 + 2]], PALETTE);
  }

  // 肤色保护（上游量化阶段）：原始色是肤色系（浅暖色）的格子，禁止被量化成中性浅色
  // （白/烟灰），否则后续背景洪水会把它们当背景清掉，人脸被吞出洞
  {
    const isSkinLab = l => l[0] > 60 && (l[1] > 4 || l[2] > 12);
    const skinIdx = PALETTE.map((p, i) => i).filter(i => isSkinLab(PALETTE[i].lab));
    if (skinIdx.length) {
      const skinPal = skinIdx.map(i => PALETTE[i]);
      for (let i = 0; i < gw * gh; i++) {
        if (grid[i] < 0) continue;
        const l = [labs[i * 3], labs[i * 3 + 1], labs[i * 3 + 2]];
        if (!isSkinLab(l)) continue; // 原始色不是肤色，不干预
        if (isSkinLab(PALETTE[grid[i]].lab)) continue; // 判色已是肤色系，无需干预
        grid[i] = skinIdx[nearest(l, skinPal)];
      }
    }
  }

  if ($('skipWhite').checked) {
    // 浅色背景只清“与画布边缘连通”的部分，主体内部的白色高光（眼睛反光、镜片）得以保留
    // 边界洪水填充：浅色/深色背景分两轮独立扩散，互不越界
    // （若合并为一轮，深色背景会"爬"进与边缘连通的亮皮肤，把脸吃空）
    const neutral = i => {
      const p = PALETTE[grid[i]].lab;
      return Math.abs(p[1]) < 12 && Math.abs(p[2]) < 12;
    };
    const flood = pass => {
      const q = [], seen = new Uint8Array(gw * gh);
      for (let x = 0; x < gw; x++) q.push(x, (gh - 1) * gw + x);
      for (let y = 0; y < gh; y++) q.push(y * gw, y * gw + gw - 1);
      while (q.length) {
        const i = q.pop();
        if (seen[i] || grid[i] < 0 || !pass(i)) continue;
        seen[i] = 1; grid[i] = -1;
        const x = i % gw, y = (i / gw) | 0;
        if (x > 0) q.push(i - 1);
        if (x < gw - 1) q.push(i + 1);
        if (y > 0) q.push(i - gw);
        if (y < gh - 1) q.push(i + gw);
      }
    };
    // 背景色在生成时重采样：去光影/增强会改变亮度，用导入时记录的背景色会失配导致清背景失效
    let refLab = BG_LAB;
    {
      const cs = [[0, 0], [gw - 1, 0], [0, gh - 1], [gw - 1, gh - 1]].map(([cx, cy]) => {
        let r = 0, g = 0, b = 0, n = 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const x = Math.min(gw - 1, Math.max(0, cx + dx)), y = Math.min(gh - 1, Math.max(0, cy + dy));
          const p = (y * gw + x) * 4;
          if (data[p + 3] < 128) continue;
          r += data[p]; g += data[p + 1]; b += data[p + 2]; n++;
        }
        return n ? [r / n, g / n, b / n] : null;
      }).filter(Boolean);
      if (cs.length >= 2) {
        const near = cs.filter(c => Math.abs(c[0] - cs[0][0]) <= 16 && Math.abs(c[1] - cs[0][1]) <= 16 && Math.abs(c[2] - cs[0][2]) <= 16);
        if (near.length >= 2) {
          const avg = [0, 0, 0];
          near.forEach(c => { avg[0] += c[0]; avg[1] += c[1]; avg[2] += c[2]; });
          refLab = srgb2lab(avg[0] / near.length, avg[1] / near.length, avg[2] / near.length);
        }
      }
    }
    // 肤色系色号永不被背景洪水清除：浅暖色（偏红/偏黄）是人脸肤色，与白底色差小，
    // 一旦通过下巴/耳侧与背景连通就会被洪水误吞成空白
    const isSkin = i => {
      const p = PALETTE[grid[i]].lab;
      return p[0] > 60 && (p[1] > 4 || p[2] > 12);
    };
    flood(i => { // 浅色背景：按重采样到的背景色清（ΔE ≤10），只清几乎纯白的背景
      if (!neutral(i) || isSkin(i)) return false;
      const p = PALETTE[grid[i]].lab;
      if (refLab) {
        const d2 = (p[0] - refLab[0]) ** 2 + (p[1] - refLab[1]) ** 2 + (p[2] - refLab[2]) ** 2;
        return d2 <= 100;
      }
      return p[0] >= 78;
    });
    // 深色背景清除前先判断边框是否真被深色占据：
    // 深色主体顶到画面边缘（拳头/剪影/黑发）时，若直接洪水会把主体整块吃掉
    let darkEdge = 0, edgeN = 0;
    for (let x = 0; x < gw; x++) for (const i of [x, (gh - 1) * gw + x]) {
      edgeN++; if (grid[i] >= 0 && neutral(i) && PALETTE[grid[i]].lab[0] < 58) darkEdge++;
    }
    for (let y = 1; y < gh - 1; y++) for (const i of [y * gw, y * gw + gw - 1]) {
      edgeN++; if (grid[i] >= 0 && neutral(i) && PALETTE[grid[i]].lab[0] < 58) darkEdge++;
    }
    if (darkEdge / edgeN > 0.35) flood(i => neutral(i) && PALETTE[grid[i]].lab[0] < 58);
    // 全局补清（白底关键修复）：白底图常带渐变/阴影/偏米白，边缘洪水只清与画布四边连通的部分，
    // 画面内部的浅色背景块（阴影、渐变灰、抗锯齿浅粉）会残留成零散豆子。这里把"任意位置的浅中性格子"
    // 以及"与背景色极近(ΔE≤16)的格子"全部清空（肤色系保留，避免误吞人脸）。对白底图这正是期望行为：
    // 白/浅灰背景一律留空，只留主体彩色。
    for (let i = 0; i < gw * gh; i++) {
      if (grid[i] < 0) continue;
      const p = PALETTE[grid[i]].lab;
      if (isSkin(i)) continue;
      const lightNeutral = p[0] >= 82 && Math.abs(p[1]) < 14 && Math.abs(p[2]) < 14;
      const nearBg = refLab && ((p[0] - refLab[0]) ** 2 + (p[1] - refLab[1]) ** 2 + (p[2] - refLab[2]) ** 2) <= 256;
      if (lightNeutral || nearBg) grid[i] = -1;
    }
  }

  // 浅色光晕清除（独立 pass，由"清除浅色光晕"开关控制，默认开）：红/彩图在浅底上的抗锯齿边缘
  // 常被量化成浅粉等浅色调噪点，它们带色调、不是中性灰，上面的背景洪水（只认 neutral）清不掉，散布在图案里像一坨。
  // 收紧策略（避免误吃白底图里的浅色内容）：
  //  1) 仅清"极高亮度 + 极低饱和"的近白色（白/浅灰/浅奶油），浅粉/浅黄/天蓝等带色调的浅色内容保留；
  //  2) 只清"四边外围一圈"：环外（内容内部）即使近白也保留，洪水不深入内容。
  if ($('lightHalo') && $('lightHalo').checked) {
    const RING = Math.max(3, Math.round(Math.min(gw, gh) * 0.05)); // 外围环厚度（格）
    const inRing = i => {
      const x = i % gw, y = (i / gw) | 0;
      return x < RING || y < RING || x >= gw - RING || y >= gh - RING;
    };
    const isLightHalo = i => {
      if (grid[i] < 0) return false;
      const p = PALETTE[grid[i]].lab;
      return p[0] >= 88 && Math.hypot(p[1], p[2]) < 22; // 仅近白，浅色内容（带色调）保留
    };
    const q2 = [], seen2 = new Uint8Array(gw * gh);
    for (let x = 0; x < gw; x++) { q2.push(x); q2.push((gh - 1) * gw + x); }
    for (let y = 0; y < gh; y++) { q2.push(y * gw); q2.push(y * gw + gw - 1); }
    while (q2.length) {
      const i = q2.pop();
      if (seen2[i] || grid[i] < 0) continue;
      seen2[i] = 1;
      // 只清"外围环内 + 近白"的浅色光晕；环外或带色调的浅色内容一律保留
      if (!inRing(i) || !isLightHalo(i)) continue;
      grid[i] = -1;
      const x = i % gw, y = (i / gw) | 0;
      if (x > 0) q2.push(i - 1);
      if (x < gw - 1) q2.push(i + 1);
      if (y > 0) q2.push(i - gw);
      if (y < gh - 1) q2.push(i + gw);
    }
  }

  // 跳过黑底：黑底素材（如黑底设计图）整片黑被映射成黑豆铺满，洪水只走近黑中性格子，
  // 从四边扩散清除与边缘连通的黑底背景，红/彩前景不被清（其格子不是黑，洪水在此停住）
  if ($('skipBlack') && $('skipBlack').checked) {
    const isDarkBg = i => {
      if (grid[i] < 0) return false;
      const p = PALETTE[grid[i]].lab;
      return p[0] < 40 && Math.abs(p[1]) < 16 && Math.abs(p[2]) < 16; // 近黑中性
    };
    const q = [], seen = new Uint8Array(gw * gh);
    for (let x = 0; x < gw; x++) { q.push(x); q.push((gh - 1) * gw + x); }
    for (let y = 0; y < gh; y++) { q.push(y * gw); q.push(y * gw + gw - 1); }
    while (q.length) {
      const i = q.pop();
      if (seen[i] || grid[i] < 0 || !isDarkBg(i)) continue;
      seen[i] = 1; grid[i] = -1;
      const x = i % gw, y = (i / gw) | 0;
      if (x > 0) q.push(i - 1);
      if (x < gw - 1) q.push(i + 1);
      if (y > 0) q.push(i - gw);
      if (y < gh - 1) q.push(i + gw);
    }
  }

  const maxC = +$('maxColors').value;
  if (maxC < PALETTE.length) {
    const count = {};
    grid.forEach(i => { if (i >= 0) count[i] = (count[i] || 0) + 1; });
    let keepIdx = Object.entries(count).sort((a, b) => b[1] - a[1]).slice(0, maxC).map(e => +e[0]);
    // 深色保护：深色色号（L<40）即使面积很小也保留，避免黑线、镜框被裁掉后串到棕/灰
    const darkKeep = Object.keys(count).map(Number)
      .filter(k => PALETTE[k].lab[0] < 40 && count[k] >= 3 && !keepIdx.includes(k));
    keepIdx = keepIdx.concat(darkKeep);
    const keepPal = keepIdx.map(i => PALETTE[i]);
    // 肤色保护延续到裁剪：被裁的肤色色号只能重映射到保留色里的肤色系，
    // 否则人脸会被映射成白色，再被背景洪水清掉
    const isSkinP = p => p.lab[0] > 60 && (p.lab[1] > 4 || p.lab[2] > 12);
    const keepSkin = keepIdx.filter(i => isSkinP(PALETTE[i]));
    const keepSkinPal = keepSkin.map(i => PALETTE[i]);
    for (let i = 0; i < grid.length; i++) {
      if (grid[i] < 0) continue;
      const p = PALETTE[grid[i]];
      if (keepSkin.length && isSkinP(p)) grid[i] = keepSkin[nearest(p.lab, keepSkinPal)];
      else grid[i] = keepIdx[nearest(p.lab, keepPal)];
    }
  }

  // 黑色保护：格内有深色证据（深色覆盖 ≥18% 或含极暗像素）且被判成中性灰的，判回纯黑
  // 不再要求“邻格已是黑”，修掉细线冷启动时整条线都救不回来的死锁
  {
    let dk = 0;
    for (let i = 1; i < PALETTE.length; i++) if (PALETTE[i].lab[0] < PALETTE[dk].lab[0]) dk = i;
    for (let i = 0; i < gw * gh; i++) {
      if (grid[i] < 0) continue;
      if (!(cover[i] >= 0.18 || minL[i] <= 32)) continue;
      const p = PALETTE[grid[i]].lab;
      if (p[0] < 32 || p[0] >= 72) continue; // 已是深色、或明显偏亮，跳过
      if (Math.hypot(p[1], p[2]) >= 12) {
        // 有色调的误判：k-means 聚类中心偏移会把黑发拉成棕色。深色证据足够强
        // （含近纯黑像素 且 深色覆盖 ≥35%）而判色又明显偏亮（L≥40）时，仍判黑。
        // 真正的黑红镜框/酒红衣物 L<32 已在上面跳过，不受影响
        if (!(minL[i] <= 24 && cover[i] >= 0.35 && p[0] >= 40)) continue;
      }
      grid[i] = dk;
    }
  }
  // 白线保护（黑色保护的镜像）：深红/深色底上的白线（拳头、闪电勾边）会被 medoid
  // 多数票吞成红剪影。白证据强（l>235 像素覆盖 ≥18%）且判色明显偏暗的格，强制判白
  {
    let wt = 0;
    for (let i = 1; i < PALETTE.length; i++) if (PALETTE[i].lab[0] > PALETTE[wt].lab[0]) wt = i;
    for (let i = 0; i < gw * gh; i++) {
      if (grid[i] < 0) continue;
      if (wcover[i] < 0.18 || cover[i] >= 0.18) continue; // 白证据不足，或深色证据优先归黑色保护管
      const p = PALETTE[grid[i]].lab;
      if (p[0] >= 78) continue; // 已是浅色，无需救
      grid[i] = wt;
    }
  }
  // 近似色合并：按使用频率降序，低频色整体并入 Lab 距离最近的高频色。
  // 高频主色永不被稀释（只进不出），阈值由滑块控制（0=关，100≈ΔE30，很激进）
  {
    const mt = $('mergeThresh') ? +$('mergeThresh').value : 0;
    if (mt > 0) {
      const t2 = (mt * 0.3) ** 2;
      const count = {};
      grid.forEach(i => { if (i >= 0) count[i] = (count[i] || 0) + 1; });
      const byFreq = Object.keys(count).map(Number).sort((a, b) => count[b] - count[a]);
      const alive = [], merged = new Map();
      for (const idx of byFreq) {
        let best = -1, bd = Infinity;
        for (const a of alive) {
          const p = PALETTE[a].lab, q = PALETTE[idx].lab;
          const d = (p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 + (p[2] - q[2]) ** 2;
          if (d < bd) { bd = d; best = a; }
        }
        if (best >= 0 && bd < t2) merged.set(idx, best);
        else alive.push(idx);
      }
      if (merged.size) for (let i = 0; i < grid.length; i++) if (merged.has(grid[i])) grid[i] = merged.get(grid[i]);
    }
  }
  // 去噪：孤立豆子（无同色邻居且邻居有多数色）替换为邻居多数色
  if ($('denoise') && $('denoise').checked) {
    const src = grid.slice();
    for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) {
      const i = y * gw + x, v = src[i];
      if (v < 0) continue;
      const cnt = {};
      let same = 0, total = 0;
      for (let d = 0; d < 4; d++) {
        const nx = x + [1, -1, 0, 0][d], ny = y + [0, 0, 1, -1][d];
        if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
        const nv = src[ny * gw + nx];
        if (nv < 0) continue;
        total++;
        if (nv === v) same++;
        cnt[nv] = (cnt[nv] || 0) + 1;
      }
      if (same === 0 && total >= 3) {
        let best = v, bn = 0;
        for (const k in cnt) if (cnt[k] > bn) { bn = cnt[k]; best = +k; }
        if (bn * 2 >= total) grid[i] = best;
      }
    }
  }
  // 灰色杂点并色：低饱和的浅灰孤立豆（阴影、纹理过渡）并入周围非灰主色，避免毛发里出现脏灰点；
  // 成片的灰色区域（灰背景、灰色物体）同色邻居多，不受影响
  for (let pass = 0; pass < 2; pass++) {
    const src = grid.slice();
    let changed = 0;
    for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) {
      const i = y * gw + x, v = src[i];
      if (v < 0) continue;
      const lb = PALETTE[v].lab;
      const chroma = Math.hypot(lb[1], lb[2]);
      if (!(lb[0] >= 56 && lb[0] < 88 && chroma <= 10)) continue; // 只处理浅/中性的灰
      const cnt = {};
      let same = 0, total = 0, strong = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
        const nv = src[ny * gw + nx];
        if (nv < 0) continue;
        total++;
        if (nv === v) { same++; continue; }
        const nl = PALETTE[nv].lab;
        if (nl[0] >= 88 || Math.hypot(nl[1], nl[2]) >= 10) { // 白/奶油或有色调的邻色
          strong++;
          cnt[nv] = (cnt[nv] || 0) + 1;
        }
      }
      if (same > 1 || total < 4 || strong * 5 < total * 3) continue; // 成片灰色、或周围也都是灰，保持原样
      let best = -1, bn = 0;
      for (const k in cnt) if (cnt[k] > bn) { bn = cnt[k]; best = +k; }
      if (best >= 0) { grid[i] = best; changed++; }
    }
    if (!changed) break;
  }
  // 浅色区域压平：被白色系包围的浅灰豆并入周围主色（嘴套/高光更干净，鼻子更凸出）
  for (let pass = 0; pass < 2; pass++) {
    const src = grid.slice();
    let changed = 0;
    for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) {
      const i = y * gw + x, v = src[i];
      if (v < 0) continue;
      const L = PALETTE[v].lab[0], a = PALETTE[v].lab[1], b = PALETTE[v].lab[2];
      if (!(L >= 68 && L < 88 && Math.abs(a) <= 6 && Math.abs(b) <= 8)) continue; // 只处理浅灰
      const cnt = {};
      let white = 0, total = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
        const nv = src[ny * gw + nx];
        if (nv < 0) continue;
        total++;
        const lj = PALETTE[nv].lab;
        // 浅色家族 = 白/奶油(L≥88) 或 暖调浅色(L≥80 且带色调)，浅灰自己不算支持者
        if (lj[0] >= 88 || (lj[0] >= 80 && Math.abs(lj[2]) > 8)) { white++; cnt[nv] = (cnt[nv] || 0) + 1; }
      }
      if (total >= 5 && white * 5 >= total * 3) {
        let best = v, bn = 0;
        for (const k in cnt) if (cnt[k] > bn) { bn = cnt[k]; best = +k; }
        if (bn > 0) { grid[i] = best; changed++; }
      }
    }
    if (!changed) break;
  }
  // 像素图模式：过滤小面积高饱和红色连通域（图纸截图里的"禁止商用"类水印红字会被量化进图纸）
  if (PIXEL_ART) {
    const isRed = idx => {
      const p = PALETTE[idx].rgb;
      return p[0] > 150 && p[1] < 110 && p[2] < 110;
    };
    const seenW = new Uint8Array(gw * gh);
    for (let s = 0; s < gw * gh; s++) {
      if (seenW[s] || grid[s] < 0 || !isRed(grid[s])) continue;
      const comp = [], q = [s];
      seenW[s] = 1;
      while (q.length) {
        const i = q.pop(); comp.push(i);
        const x = i % gw, y = (i / gw) | 0;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = x + dx, ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
          const j = ny * gw + nx;
          if (!seenW[j] && grid[j] >= 0 && isRed(grid[j])) { seenW[j] = 1; q.push(j); }
        }
      }
      if (comp.length >= 8) continue; // 大块红色是真内容（衣服/苹果），不动
      const cnt = {};
      for (const i of comp) {
        const x = i % gw, y = (i / gw) | 0;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = x + dx, ny = y + dy;
          if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
          const nv = grid[ny * gw + nx];
          if (nv >= 0 && !isRed(nv)) cnt[nv] = (cnt[nv] || 0) + 1;
        }
      }
      let best = -1, bn = 0;
      for (const k in cnt) if (cnt[k] > bn) { bn = cnt[k]; best = +k; }
      for (const i of comp) grid[i] = best >= 0 ? best : -1; // 无邻居参照的孤立水印直接清空
    }
  }
  render();
  buildStats();
}

function applyZoom() {
  const c = $('canvas'); if (!c || !c.width) return;
  const wrap = $('canvasWrap');
  const avail = (wrap.clientWidth || 800) - 8;
  const z = (+$('zoom').value) / 100;
  const fit = avail / c.width;
  c.style.maxWidth = 'none';
  c.style.width = Math.max(40, Math.round(c.width * fit * z)) + 'px';
  c.style.height = 'auto';
  const zl = $('zoomLabel');
  if (zl) zl.textContent = (z * 100).toFixed(0) + '%' + (z === 1 ? '（适应）' : '');
}

function render() {
  const showGrid = $('grid').checked;
  const cell = Math.max(28, Math.floor(1800 / Math.max(gw, gh)));
  const showCodes = $('showCodes') && $('showCodes').checked;
  const numH = 16, titleH = 28, legendH = 26, sidePad = 20;
  const blockW = gw * cell + 20 + 20;
  const blockH = titleH + numH + gh * cell + numH + legendH;
  const c = $('canvas');
  c.width = blockW + sidePad * 2;
  c.height = blockH + sidePad * 2;
  const ctx = c.getContext('2d');
  const dark = $('bgDark') && $('bgDark').checked;
  const BG = dark ? '#0e0e10' : '#ffffff';
  const GRID = dark ? 'rgba(255,255,255,.16)' : 'rgba(0,0,0,.14)';
  const FRAME = dark ? '#9aa0a6' : '#000';
  const NUM = dark ? '#c8ccd0' : '#333';
  const TITLE = dark ? '#e6e8ea' : '#222';

  ctx.fillStyle = BG; ctx.fillRect(0, 0, c.width, c.height);
  const blockX = (c.width - blockW) / 2;
  const blockY = (c.height - blockH) / 2;
  const gx = blockX + 20;
  const gy = blockY + titleH + numH;

  // 2. 豆子（先铺满实色，色号按底色深浅取黑/白）
  const txtSize = Math.max(7, Math.floor(cell * 0.36));
  ctx.font = `bold ${txtSize}px sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) {
    const i = grid[y * gw + x];
    if (i < 0) continue;
    const bx = gx + x * cell, by = gy + y * cell;
    ctx.fillStyle = PALETTE[i].hex;
    ctx.fillRect(bx, by, cell, cell);
    if (showCodes) {
      ctx.fillStyle = lum(PALETTE[i]) > 0.68 ? 'rgba(0,0,0,.78)' : 'rgba(255,255,255,.92)';
      ctx.fillText(brandCode(PALETTE[i]), bx + cell / 2, by + cell / 2);
    }
  }

  // 3. 细网格压在豆子上层（参考图：格子线穿过豆子仍可见）
  if (showGrid) {
    ctx.strokeStyle = GRID; ctx.lineWidth = 1;
    for (let x = 0; x <= gw; x++) {
      ctx.beginPath(); ctx.moveTo(gx + x * cell + .5, gy); ctx.lineTo(gx + x * cell + .5, gy + gh * cell); ctx.stroke();
    }
    for (let y = 0; y <= gh; y++) {
      ctx.beginPath(); ctx.moveTo(gx, gy + y * cell + .5); ctx.lineTo(gx + gw * cell, gy + y * cell + .5); ctx.stroke();
    }
  }

  // 4. 红色实线（每 10 格）+ 交点红点
  ctx.strokeStyle = 'rgba(226,75,75,.72)'; ctx.lineWidth = 1.5;
  for (let x = 10; x < gw; x += 10) {
    ctx.beginPath(); ctx.moveTo(gx + x * cell + .5, gy); ctx.lineTo(gx + x * cell + .5, gy + gh * cell); ctx.stroke();
  }
  for (let y = 10; y < gh; y += 10) {
    ctx.beginPath(); ctx.moveTo(gx, gy + y * cell + .5); ctx.lineTo(gx + gw * cell, gy + y * cell + .5); ctx.stroke();
  }
  ctx.fillStyle = 'rgba(226,75,75,.85)';
  for (let x = 10; x < gw; x += 10) for (let y = 10; y < gh; y += 10) {
    ctx.beginPath(); ctx.arc(gx + x * cell, gy + y * cell, 2.2, 0, 6.2832); ctx.fill();
  }

  // 5. 外黑框
  ctx.strokeStyle = FRAME; ctx.lineWidth = 2;
  ctx.strokeRect(gx, gy, gw * cell, gh * cell);

  // 6. 行列号（上/下/左/右四边）
  ctx.fillStyle = NUM; ctx.textBaseline = 'middle';
  const numSize = Math.max(9, Math.min(12, cell * 0.5));
  ctx.font = `${numSize}px sans-serif`;
  ctx.textAlign = 'center';
  for (let x = 0; x < gw; x++) ctx.fillText(String(x + 1), gx + x * cell + cell / 2, blockY + titleH + numH / 2);
  for (let x = 0; x < gw; x++) ctx.fillText(String(x + 1), gx + x * cell + cell / 2, gy + gh * cell + numH / 2);
  ctx.textAlign = 'right';
  for (let y = 0; y < gh; y++) ctx.fillText(String(y + 1), gx - 4, gy + y * cell + cell / 2);
  ctx.textAlign = 'left';
  for (let y = 0; y < gh; y++) ctx.fillText(String(y + 1), gx + gw * cell + 4, gy + y * cell + cell / 2);

  // 7. 顶部标题
  const count = {}; grid.forEach(i => { if (i >= 0) count[i] = (count[i] || 0) + 1; });
  const total = Object.values(count).reduce((s, n) => s + n, 0);
  ctx.fillStyle = TITLE; ctx.font = 'bold 14px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(`[${gw}×${gh}/${Object.keys(count).length}色/共${total}颗]`, c.width / 2, blockY + titleH / 2);

  // 8. 底部图例
  const legendY = gy + gh * cell + numH + 5;
  const sw = 16, sh = 16, gap = 6;
  ctx.font = `${Math.max(10, cell * 0.4)}px sans-serif`; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  const rows = Object.entries(count).sort((a, b) => b[1] - a[1]);
  let lx = 20;
  for (const [idx, n] of rows) {
    const p = PALETTE[idx];
    const label = `${brandCode(p)} ${n}`;
    ctx.fillStyle = p.hex;
    ctx.fillRect(lx, legendY, sw, sh);
    ctx.strokeStyle = '#333'; ctx.lineWidth = 1;
    ctx.strokeRect(lx + .5, legendY + .5, sw - 1, sh - 1);
    ctx.fillStyle = '#222';
    ctx.fillText(label, lx + sw + gap, legendY + sh / 2);
    lx += sw + gap + ctx.measureText(label).width + 16;
    if (lx > c.width - 20) { lx = 20; break; }
  }

  $('hint').hidden = true;
  $('exportCard').hidden = false;
  $('statsCard').hidden = false;
  applyZoom();
}

function buildStats() {
  const count = {};
  grid.forEach(i => { if (i >= 0) count[i] = (count[i] || 0) + 1; });
  const rows = Object.entries(count).sort((a, b) => b[1] - a[1]);
  $('stats').tBodies[0].innerHTML = rows.map(([idx, n]) => {
    const p = PALETTE[idx];
    return `<tr><td><span class="sw" style="background:${p.hex}"></span></td><td>${p.name}</td><td>${n}</td></tr>`;
  }).join('');
  const total = rows.reduce((s, [, n]) => s + n, 0);
  $('total').textContent = `共 ${rows.length} 种颜色，${total} 颗豆子`;
}

$('exportPng').onclick = () => {
  // 大图纸自动缩小格子，避免导出画布过大
  const cell = Math.max(10, Math.min(24, Math.floor(4000 / Math.max(gw, gh))));
  const showCodes = $('showCodes') && $('showCodes').checked;
  const numH = 20, titleH = 36, legendH = 32, sidePad = 28;
  const blockW = gw * cell + 24 + 24;
  const blockH = titleH + numH + gh * cell + numH + legendH;
  const c = document.createElement('canvas');
  c.width = blockW + sidePad * 2;
  c.height = blockH + sidePad * 2;
  const ctx = c.getContext('2d');
  const dark = $('bgDark') && $('bgDark').checked;
  const BG = dark ? '#0e0e10' : '#ffffff';
  const GRID = dark ? 'rgba(255,255,255,.16)' : 'rgba(0,0,0,.14)';
  const FRAME = dark ? '#9aa0a6' : '#000';
  const NUM = dark ? '#c8ccd0' : '#333';
  const TITLE = dark ? '#e6e8ea' : '#222';

  ctx.fillStyle = BG; ctx.fillRect(0, 0, c.width, c.height);
  const blockX = (c.width - blockW) / 2;
  const blockY = (c.height - blockH) / 2;
  const gx = blockX + 24;
  const gy = blockY + titleH + numH;

  // 豆子（先铺实色 + 色号）
  ctx.font = 'bold 10px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) {
    const i = grid[y * gw + x];
    if (i < 0) continue;
    const bx = gx + x * cell, by = gy + y * cell;
    ctx.fillStyle = PALETTE[i].hex; ctx.fillRect(bx, by, cell, cell);
    if (showCodes) {
      ctx.fillStyle = lum(PALETTE[i]) > 0.68 ? 'rgba(0,0,0,.78)' : 'rgba(255,255,255,.92)';
      ctx.fillText(brandCode(PALETTE[i]), bx + cell / 2, by + cell / 2);
    }
  }

  // 细网格压在豆子上层
  ctx.strokeStyle = GRID; ctx.lineWidth = 1;
  for (let x = 0; x <= gw; x++) { ctx.beginPath(); ctx.moveTo(gx + x * cell + .5, gy); ctx.lineTo(gx + x * cell + .5, gy + gh * cell); ctx.stroke(); }
  for (let y = 0; y <= gh; y++) { ctx.beginPath(); ctx.moveTo(gx, gy + y * cell + .5); ctx.lineTo(gx + gw * cell, gy + y * cell + .5); ctx.stroke(); }

  // 红色实线（每 10）+ 交点红点
  ctx.strokeStyle = 'rgba(226,75,75,.72)'; ctx.lineWidth = 2;
  for (let x = 10; x < gw; x += 10) { ctx.beginPath(); ctx.moveTo(gx + x * cell + .5, gy); ctx.lineTo(gx + x * cell + .5, gy + gh * cell); ctx.stroke(); }
  for (let y = 10; y < gh; y += 10) { ctx.beginPath(); ctx.moveTo(gx, gy + y * cell + .5); ctx.lineTo(gx + gw * cell, gy + y * cell + .5); ctx.stroke(); }
  ctx.fillStyle = 'rgba(226,75,75,.85)';
  for (let x = 10; x < gw; x += 10) for (let y = 10; y < gh; y += 10) {
    ctx.beginPath(); ctx.arc(gx + x * cell, gy + y * cell, 3, 0, 6.2832); ctx.fill();
  }

  // 外黑框
  ctx.strokeStyle = FRAME; ctx.lineWidth = 2.5;
  ctx.strokeRect(gx, gy, gw * cell, gh * cell);

  // 行列号
  ctx.fillStyle = NUM; ctx.font = '13px sans-serif'; ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  for (let x = 0; x < gw; x++) ctx.fillText(String(x + 1), gx + x * cell + cell / 2, blockY + titleH + numH / 2);
  for (let x = 0; x < gw; x++) ctx.fillText(String(x + 1), gx + x * cell + cell / 2, gy + gh * cell + numH / 2);
  ctx.textAlign = 'right';
  for (let y = 0; y < gh; y++) ctx.fillText(String(y + 1), gx - 6, gy + y * cell + cell / 2);
  ctx.textAlign = 'left';
  for (let y = 0; y < gh; y++) ctx.fillText(String(y + 1), gx + gw * cell + 6, gy + y * cell + cell / 2);

  // 顶部标题
  const count = {}; grid.forEach(i => { if (i >= 0) count[i] = (count[i] || 0) + 1; });
  const total = Object.values(count).reduce((s, n) => s + n, 0);
  ctx.fillStyle = TITLE; ctx.font = 'bold 18px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(`[${gw}×${gh}/${Object.keys(count).length}色/共${total}颗]`, c.width / 2, blockY + titleH / 2);

  // 底部图例
  const legendY = gy + gh * cell + numH + 6;
  const rows = Object.entries(count).sort((a, b) => b[1] - a[1]);
  const sw = 18, sh = 18;
  ctx.font = '13px sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  let lx = blockX + 12;
  for (const [idx, n] of rows) {
    const p = PALETTE[idx];
    const label = `${brandCode(p)} ${n}  (${p.name})`;
    ctx.fillStyle = p.hex; ctx.fillRect(lx, legendY, sw, sh);
    ctx.strokeStyle = '#333'; ctx.lineWidth = 1; ctx.strokeRect(lx + .5, legendY + .5, sw - 1, sh - 1);
    ctx.fillStyle = '#222'; ctx.fillText(label, lx + sw + 8, legendY + sh / 2);
    lx += sw + 8 + ctx.measureText(label).width + 18;
    if (lx > c.width - blockX - 12) break;
  }

  const a = document.createElement('a');
  a.download = '拼豆图纸.png'; a.href = c.toDataURL('image/png'); a.click();
};

$('exportCsv').onclick = () => {
  const count = {};
  grid.forEach(i => { if (i >= 0) count[i] = (count[i] || 0) + 1; });
  const rows = Object.entries(count).sort((a, b) => b[1] - a[1]);
  let csv = '\uFEFF颜色,色号,数量\n' + rows.map(([idx, n]) =>
    `${PALETTE[idx].name},${PALETTE[idx].hex},${n}`).join('\n');
  const total = rows.reduce((s, [, n]) => s + n, 0);
  csv += `\n合计,,${total}`;
  const a = document.createElement('a');
  a.download = '采购清单.csv';
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a.click();
};

$('palImport').onclick = () => $('palFile').click();
$('palFile').onchange = e => {
  const f = e.target.files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => {
    const im = new Image();
    im.onload = () => {
      setPalette(extractPalette(im));
      $('palTip').textContent = `✅ 已从「${f.name}」提取 ${PALETTE.length} 色，后续图纸将按此色板生成`;
    };
    im.src = reader.result;
  };
  reader.readAsDataURL(f);
  e.target.value = '';
};
$('palReset').onclick = () => {
  setPalette(DEFAULT_PALETTE);
  $('palTip').textContent = `已恢复默认 ${DEFAULT_PALETTE.length} 色色板`;
};

setPalette(DEFAULT_PALETTE);

