#!/bin/bash
cd "$(dirname "$0")"

# 优先 Python
if command -v python3 >/dev/null 2>&1; then
  echo "正在启动拼豆服务器..."
  open "http://127.0.0.1:8000/"
  python3 -m http.server 8000 --bind 127.0.0.1
  exit 0
fi

# 退而 Node
if command -v node >/dev/null 2>&1; then
  echo "正在启动拼豆服务器..."
  open "http://127.0.0.1:8000/"
  node server.js
  exit 0
fi

echo ""
echo "[提示] 未检测到 Python3 或 Node.js。"
echo "直接双击 index.html 即可使用。"
read -n 1 -s -r -p "按任意键退出..."
