@echo off
chcp 65001 >nul
title 拼豆图纸生成器
cd /d "%~dp0"

rem 优先用 Python 启服务器（大多数电脑自带）
where python >nul 2>&1
if %errorlevel%==0 (
  echo 正在启动拼豆服务器...
  start "" http://127.0.0.1:8000/
  python -m http.server 8000 --bind 127.0.0.1
  goto end
)

rem 退而用 Node
where node >nul 2>&1
if %errorlevel%==0 (
  echo 正在启动拼豆服务器...
  start "" http://127.0.0.1:8000/
  node server.js
  goto end
)

echo.
echo [错误] 未检测到 Python 或 Node.js，无法自动启动服务器。
echo.
echo 最简单的方式：直接双击 index.html 即可使用（浏览器会弹出安全提示，点"允许"即可）。
echo.
echo 或者安装 Python 后重新运行本脚本：https://www.python.org/downloads/
echo.
pause
:end
